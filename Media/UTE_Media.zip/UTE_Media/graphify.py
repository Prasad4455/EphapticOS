#!/usr/bin/env python3
"""Minimal graphify utility for this repository.

Usage:
    python graphify.py update .
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def build_graph(repo_root: Path) -> dict[str, Any]:
    repo_name = repo_root.name
    root_node = {
        "id": "repo",
        "type": "project",
        "label": repo_name,
        "path": ".",
        "description": "AI-powered troubleshooting agent for production incidents and root-cause analysis.",
    }

    nodes = [
        root_node,
        {
            "id": "readme",
            "type": "document",
            "label": "README",
            "path": "README.md",
            "description": "Product overview, feature summary, and installation guidance.",
        },
        {
            "id": "main",
            "type": "entrypoint",
            "label": "UTE.main",
            "path": "UpTimeEngine/main.py",
            "description": "Typer CLI entry point and investigation command wiring.",
        },
        {
            "id": "config",
            "type": "module",
            "label": "Config",
            "path": "UpTimeEngine/config.py",
            "description": "Load configuration, toolsets, and model settings for runtime operation.",
        },
        {
            "id": "server",
            "type": "service",
            "label": "Server",
            "path": "server.py",
            "description": "HTTP/API service entry point for the runtime and status endpoints.",
        },
        {
            "id": "core",
            "type": "package",
            "label": "UpTimeEngine.core",
            "path": "UpTimeEngine/core",
            "description": "Prompting, LLM orchestration, tool execution, investigation flow, and tracing.",
        },
        {
            "id": "plugins",
            "type": "package",
            "label": "UpTimeEngine.plugins",
            "path": "UpTimeEngine/plugins",
            "description": "Built-in integrations for sources, toolsets, destinations, prompts, and skills.",
        },
        {
            "id": "tests",
            "type": "package",
            "label": "tests",
            "path": "tests",
            "description": "Unit, integration, and LLM evaluation coverage.",
        },
        {
            "id": "docs",
            "type": "package",
            "label": "docs",
            "path": "docs",
            "description": "Documentation and installation guidance for users and operators.",
        },
    ]

    edges = [
        {"source": "repo", "target": "readme", "kind": "documents"},
        {"source": "repo", "target": "main", "kind": "contains"},
        {"source": "repo", "target": "config", "kind": "contains"},
        {"source": "repo", "target": "server", "kind": "contains"},
        {"source": "repo", "target": "core", "kind": "contains"},
        {"source": "repo", "target": "plugins", "kind": "contains"},
        {"source": "repo", "target": "tests", "kind": "contains"},
        {"source": "repo", "target": "docs", "kind": "contains"},
        {"source": "main", "target": "config", "kind": "uses"},
        {"source": "main", "target": "core", "kind": "orchestrates"},
        {"source": "server", "target": "core", "kind": "connects_to"},
        {"source": "server", "target": "plugins", "kind": "loads"},
        {"source": "config", "target": "plugins", "kind": "configures"},
        {"source": "core", "target": "plugins", "kind": "invokes"},
        {"source": "tests", "target": "core", "kind": "verifies"},
        {"source": "tests", "target": "plugins", "kind": "validates"},
        {"source": "docs", "target": "readme", "kind": "references"},
    ]

    return {
        "schema_version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "project": repo_name,
        "nodes": nodes,
        "edges": edges,
    }


def write_graph_artifacts(repo_root: Path) -> Path:
    out_dir = repo_root / "graphify-out"
    wiki_dir = out_dir / "wiki"
    wiki_dir.mkdir(parents=True, exist_ok=True)

    graph = build_graph(repo_root)
    graph_path = out_dir / "graph.json"
    graph_path.write_text(json.dumps(graph, indent=2) + "\n", encoding="utf-8")

    report = """# UpTimeEngine Graph Report

## Project overview

This repository implements UpTimeEngine, an AI-powered incident investigation system that queries observability and operational data sources to diagnose production issues.

## Key architectural components

- CLI entrypoint: `UpTimeEngine/main.py`
- Configuration and runtime setup: `UpTimeEngine/config.py`
- HTTP service layer: `server.py`
- Investigation orchestration: `UpTimeEngine/core/`
- Source and tool integrations: `UpTimeEngine/plugins/`
- End-to-end validation: `tests/`
- User and operator docs: `docs/`

## Relationship summary

- The CLI and server layers both depend on the shared configuration and core investigation engine.
- The core package coordinates prompts, tool execution, tracing, and model interactions.
- The plugins layer gives the agent access to data sources, destinations, skills, and runbooks.
- Tests validate both the core control flow and the integration surface.

## Repository map

- `README.md` contains the product overview and data-source inventory.
- `UpTimeEngine/` holds the runtime package and core logic.
- `server.py` provides the API service entrypoint.
- `tests/` contains the regression and evaluation suites.
- `docs/` holds the user-facing documentation and installation guidance.

## Summary

The repository is organized as a tool-using agent framework: configuration loads integrations, the core engine orchestrates LLM-driven investigations, plugins provide access to external systems, and tests verify behavior against real operational workflows.
"""
    (out_dir / "GRAPH_REPORT.md").write_text(report, encoding="utf-8")

    wiki_index = """# Knowledge graph index

- [Project graph](../graph.json)
- [Project report](../GRAPH_REPORT.md)
- [Repository overview](../../README.md)

## Main entrypoints

- `UpTimeEngine/main.py` — CLI and investigation commands
- `server.py` — FastAPI service and background runtime
- `UpTimeEngine/config.py` — shared runtime configuration
- `UpTimeEngine/core/` — orchestration, tools, prompts, trace handling
- `UpTimeEngine/plugins/` — integrations and toolsets
- `tests/` — coverage and evaluation harness
"""
    (wiki_dir / "index.md").write_text(wiki_index, encoding="utf-8")

    return graph_path


def main() -> None:
    parser = argparse.ArgumentParser(prog="graphify")
    parser.add_argument("command", choices=["update"], nargs="?", default="update")
    parser.add_argument("path", nargs="?", default=".")
    args = parser.parse_args()

    repo_root = Path(args.path).resolve()
    if not repo_root.exists():
        raise FileNotFoundError(f"Path does not exist: {repo_root}")

    graph_path = write_graph_artifacts(repo_root)
    print(f"Graph updated at {graph_path}")


if __name__ == "__main__":
    main()
