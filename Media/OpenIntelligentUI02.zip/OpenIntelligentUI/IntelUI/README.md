# UpTimeEngineUI — Wells Fargo Brand Standards SRE Generative UI Demo

See [`../UpTimeEngineUI/README.md`](../UpTimeEngineUI/README.md) or run [`Launch-UpTimeEngineUI.bat`](./Launch-UpTimeEngineUI.bat).
