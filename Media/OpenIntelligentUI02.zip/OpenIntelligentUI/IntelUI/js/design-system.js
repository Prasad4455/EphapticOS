/**
 * UpTimeEngineUI — OpenIntelligentUI Design System & Sandbox Bridge
 * Styled according to Wells Fargo Brand Standards (#D71E28 Crimson, #FFCD41 Stagecoach Gold).
 * Preserves OpenIntelligentUI's THEME_CSS, SVG_CLASSES_CSS, FORM_STYLES_WITH_STAGGER_CSS,
 * continuous ResizeObserver MEASUREMENT_JS, and Websandbox.connection.remote.sendPrompt bridge.
 */

window.IntelUIDesignSystem = (function () {
  const RESIZE_MESSAGE_TYPE = "__ogui_resize";
  const PROMPT_MESSAGE_TYPE = "__ogui_send_prompt";
  const OPEN_LINK_MESSAGE_TYPE = "__ogui_open_link";

  // OpenIntelligentUI canonical theme variables + Wells Fargo Brand Standards tokens
  const THEME_CSS = `
:root {
  --wf-red: #D71E28;
  --wf-red-dark: #9B111E;
  --wf-gold: #FFCD41;
  --wf-gold-bright: #FFFF00;
  --wf-gold-deep: #D99B00;

  --color-background-primary: #120E10;
  --color-background-secondary: #1B1417;
  --color-background-tertiary: #261C20;
  --color-background-glass: rgba(27, 20, 23, 0.82);
  --color-background-info: rgba(255, 205, 65, 0.14);
  --color-background-danger: rgba(215, 30, 40, 0.2);
  --color-background-success: rgba(16, 185, 129, 0.15);
  --color-background-warning: rgba(245, 158, 11, 0.16);

  --color-text-primary: #FAF8F5;
  --color-text-secondary: #C8BFC2;
  --color-text-tertiary: #8F8286;
  --color-text-info: #FFCD41;
  --color-text-danger: #FF6B72;
  --color-text-success: #34D399;
  --color-text-warning: #FBBF24;

  --color-border-primary: rgba(255, 205, 65, 0.45);
  --color-border-secondary: rgba(255, 205, 65, 0.24);
  --color-border-tertiary: rgba(200, 191, 194, 0.14);
  --color-border-info: rgba(255, 205, 65, 0.55);
  --color-border-danger: rgba(215, 30, 40, 0.6);
  --color-border-success: rgba(52, 211, 153, 0.45);
  --color-border-warning: rgba(251, 191, 36, 0.45);

  --font-sans: "Inter", "Segoe UI", system-ui, -apple-system, Roboto, sans-serif;
  --font-serif: Georgia, "Times New Roman", serif;
  --font-mono: "JetBrains Mono", "Cascadia Code", "Fira Code", Consolas, monospace;

  --border-radius-md: 8px;
  --border-radius-lg: 12px;
  --border-radius-xl: 16px;

  --p: var(--color-text-primary);
  --s: var(--color-text-secondary);
  --t: var(--color-text-tertiary);
  --bg2: var(--color-background-secondary);
  --b: var(--color-border-tertiary);
}

html[data-theme="light"] {
  --color-background-primary: #FFFFFF;
  --color-background-secondary: #FAF7F2;
  --color-background-tertiary: #F2ECE4;
  --color-background-glass: rgba(255, 255, 255, 0.92);
  --color-background-info: #FFF8E1;
  --color-background-danger: #FDECEE;
  --color-background-success: #E8F8F0;
  --color-background-warning: #FEF3C7;

  --color-text-primary: #141414;
  --color-text-secondary: #4A4446;
  --color-text-tertiary: #787073;
  --color-text-info: #B01620;
  --color-text-danger: #D71E28;
  --color-text-success: #059669;
  --color-text-warning: #B45309;

  --color-border-primary: rgba(215, 30, 40, 0.42);
  --color-border-secondary: rgba(180, 150, 90, 0.32);
  --color-border-tertiary: rgba(20, 20, 20, 0.11);
  --color-border-info: rgba(215, 30, 40, 0.48);
}
`;

  // OpenIntelligentUI SVG Pre-Built Classes
  const SVG_CLASSES_CSS = `
svg text.t   { font: 400 13px var(--font-sans); fill: var(--p); }
svg text.ts  { font: 400 11px var(--font-sans); fill: var(--s); }
svg text.th  { font: 600 13px var(--font-sans); fill: var(--p); }

svg .box > rect, svg .box > circle, svg .box > ellipse { fill: var(--bg2); stroke: var(--b); }
svg .node { cursor: pointer; transition: opacity 0.2s ease, transform 0.2s ease; }
svg .node:hover { opacity: 0.92; }
svg .arr { stroke: var(--s); stroke-width: 1.5; fill: none; }
svg .leader { stroke: var(--t); stroke-width: 0.75; stroke-dasharray: 4 4; fill: none; }

svg .c-red > rect, svg rect.c-red { fill: rgba(215, 30, 40, 0.2); stroke: #D71E28; }
svg .c-amber > rect, svg rect.c-amber { fill: rgba(255, 205, 65, 0.18); stroke: #FFCD41; }
svg .c-green > rect, svg rect.c-green { fill: rgba(16, 185, 129, 0.18); stroke: #10b981; }
svg .c-blue > rect, svg rect.c-blue { fill: rgba(56, 189, 248, 0.18); stroke: #38bdf8; }
`;

  // OpenIntelligentUI Form & Morph Enter Styles
  const FORM_STYLES_WITH_STAGGER_CSS = `
* { box-sizing: border-box; margin: 0; }
html { background: transparent; }
body {
  font-family: var(--font-sans);
  font-size: 14px;
  line-height: 1.6;
  color: var(--color-text-primary);
  background: transparent;
  -webkit-font-smoothing: antialiased;
  padding: 2px;
}
button {
  font-family: inherit;
  font-size: 12.5px;
  font-weight: 600;
  padding: 6px 13px;
  border: 1px solid var(--color-border-secondary);
  border-radius: var(--border-radius-md);
  background: rgba(38, 28, 32, 0.75);
  color: var(--color-text-primary);
  cursor: pointer;
  transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
}
html[data-theme="light"] button {
  background: #FAF7F2;
}
button:hover {
  background: rgba(215, 30, 40, 0.22);
  border-color: #FFCD41;
  transform: translateY(-1px);
}
button:active { transform: scale(0.98); }

input[type="text"],
input[type="number"],
input[type="search"],
select {
  font-family: inherit;
  font-size: 13px;
  padding: 6px 12px;
  height: 34px;
  border: 1px solid var(--color-border-secondary);
  border-radius: var(--border-radius-md);
  background: var(--color-background-primary);
  color: var(--color-text-primary);
  transition: border-color 0.15s, box-shadow 0.15s;
}
input:focus, select:focus {
  outline: none;
  border-color: #FFCD41;
  box-shadow: 0 0 0 3px rgba(255, 205, 65, 0.18);
}
input[type="range"] {
  -webkit-appearance: none;
  appearance: none;
  height: 5px;
  background: rgba(255, 205, 65, 0.25);
  border-radius: 999px;
  border: none;
  outline: none;
}
input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #FFCD41;
  border: 2px solid #D71E28;
  cursor: pointer;
  box-shadow: 0 0 10px rgba(255, 205, 65, 0.8);
}

#content.initial-render > *,
.morph-enter {
  animation: fadeSlideIn 0.42s cubic-bezier(0.16, 1, 0.3, 1) both;
}

@keyframes fadeSlideIn {
  from { opacity: 0; transform: translateY(10px); }
  to   { opacity: 1; transform: translateY(0); }
}
`;

  function buildSandboxBridgeJS(widgetId) {
    return `
(function() {
  window.Websandbox = window.Websandbox || {
    connection: {
      remote: {
        sendPrompt: function(payload) {
          var text = typeof payload === 'string' ? payload : (payload && payload.text ? payload.text : '');
          if (!text) return Promise.resolve();
          parent.postMessage({
            type: '${PROMPT_MESSAGE_TYPE}',
            widgetId: ${JSON.stringify(widgetId)},
            text: text
          }, '*');
          return Promise.resolve();
        },
        openLink: function(payload) {
          var url = typeof payload === 'string' ? payload : (payload && payload.url ? payload.url : '');
          if (!url) return Promise.resolve();
          parent.postMessage({
            type: '${OPEN_LINK_MESSAGE_TYPE}',
            widgetId: ${JSON.stringify(widgetId)},
            url: url
          }, '*');
          return Promise.resolve();
        }
      }
    }
  };

  if (window.__oguiResizeInstalled) return;
  window.__oguiResizeInstalled = true;
  var style = document.createElement('style');
  style.textContent = 'html, body { overflow: hidden !important; height: auto !important; min-height: 0 !important; }';
  document.head.appendChild(style);

  function reportHeight() {
    if (!document.body) return;
    var h = document.body.scrollHeight;
    var cs = getComputedStyle(document.body);
    h += (parseFloat(cs.marginTop) || 0) + (parseFloat(cs.marginBottom) || 0) + 4;
    parent.postMessage({
      type: '${RESIZE_MESSAGE_TYPE}',
      widgetId: ${JSON.stringify(widgetId)},
      height: Math.ceil(h)
    }, '*');
  }
  window.__reportOguiHeight = reportHeight;
  if (typeof ResizeObserver !== 'undefined') {
    var ro = new ResizeObserver(reportHeight);
    ro.observe(document.body);
  }
  window.addEventListener('resize', reportHeight);
  window.addEventListener('load', reportHeight);
  var interval = setInterval(reportHeight, 180);
  setTimeout(function() { clearInterval(interval); }, 4500);
  reportHeight();
})();
`;
  }

  function buildFrameDocument({ widgetId, css, html, jsFunctions, jsExpressions, theme = "dark" }) {
    const bridgeScript = buildSandboxBridgeJS(widgetId);
    const exprScript = Array.isArray(jsExpressions) ? jsExpressions.join("\n;\n") : (jsExpressions || "");
    return `<!DOCTYPE html>
<html lang="en" data-theme="${theme}">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>${THEME_CSS}\n${SVG_CLASSES_CSS}\n${FORM_STYLES_WITH_STAGGER_CSS}</style>
  <style>${css || ""}</style>
</head>
<body>
  <div id="content" class="initial-render">
    ${html || ""}
  </div>
  <script>${bridgeScript}<\/script>
  <script>${jsFunctions || ""}<\/script>
  <script>${exprScript}<\/script>
</body>
</html>`;
  }

  function assembleStandaloneHtml({ title, css, html, jsFunctions, jsExpressions, theme = "dark" }) {
    const exprScript = Array.isArray(jsExpressions) ? jsExpressions.join("\n;\n") : (jsExpressions || "");
    return `<!DOCTYPE html>
<html lang="en" data-theme="${theme}">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${title || "UpTimeEngineUI SRE Dashboard"}</title>
  <style>${THEME_CSS}\n${SVG_CLASSES_CSS}\n${FORM_STYLES_WITH_STAGGER_CSS}
  body { background: var(--color-background-primary); padding: 24px; max-width: 1120px; margin: 0 auto; }
  </style>
  <style>${css || ""}</style>
</head>
<body>
  <div id="content" class="initial-render">
    ${html || ""}
  </div>
  <script>
    window.Websandbox = {
      connection: {
        remote: {
          sendPrompt: function(p) {
            alert("Follow-up prompt in UpTimeEngineUI chat:\\n\\n" + (p && p.text ? p.text : p));
          },
          openLink: function(p) {
            if (p && p.url) window.open(p.url, "_blank", "noopener,noreferrer");
          }
        }
      }
    };
  <\/script>
  <script>${jsFunctions || ""}<\/script>
  <script>${exprScript}<\/script>
</body>
</html>`;
  }

  return {
    RESIZE_MESSAGE_TYPE,
    PROMPT_MESSAGE_TYPE,
    OPEN_LINK_MESSAGE_TYPE,
    THEME_CSS,
    SVG_CLASSES_CSS,
    FORM_STYLES_WITH_STAGGER_CSS,
    buildFrameDocument,
    assembleStandaloneHtml,
  };
})();
