/**
 * UpTimeEngineUI — Wells Fargo Brand Standards SRE Generative UI Scenarios
 * Includes:
 *   1. Top 10 Network & Microsoft Intune Infrastructure Alerts Today
 *   2. High Dollar-Value Application: DXC Hogan Systems (with integrated switcher for Vantage & StoreVision SVP)
 *   3. Wells Fargo Vantage Application Monitoring (Primary Environment: Cloud / Microservices / Mobile)
 *   4. Branch Network Platform: StoreVision (SVP) Health Status (Primary Environment: Enterprise Branch Workstations)
 *   5. Live Incident Blast-Radius & Dependency Topology
 *   6. Dynamic SRE Deep-Dive & Automated Runbook Executor
 */

window.IntelUIScenarios = (function () {
  const SHARED_WIDGET_CSS = `
    .sre-widget {
      background: linear-gradient(165deg, rgba(27, 20, 23, 0.95), rgba(16, 11, 13, 0.98));
      border: 1px solid rgba(255, 205, 65, 0.28);
      border-top: 3px solid #D71E28;
      border-radius: 14px;
      padding: 18px;
      color: var(--color-text-primary);
      box-shadow: inset 0 1px 0 rgba(255, 205, 65, 0.08);
    }
    html[data-theme="light"] .sre-widget {
      background: linear-gradient(165deg, #FFFFFF, #FAF7F2);
      border-color: rgba(180, 145, 70, 0.35);
      border-top: 3px solid #D71E28;
      box-shadow: 0 4px 20px rgba(20, 14, 16, 0.06);
    }
    .sre-top-bar {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding-bottom: 14px;
      margin-bottom: 16px;
      border-bottom: 1px solid var(--color-border-tertiary);
    }
    .sre-title-group {
      display: flex;
      flex-direction: column;
      gap: 3px;
    }
    .sre-eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.7px;
      color: #FFCD41;
    }
    html[data-theme="light"] .sre-eyebrow {
      color: #D71E28;
    }
    .sre-live-dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: #FFCD41;
      box-shadow: 0 0 10px #FFCD41;
      animation: pulseGlow 1.8s infinite;
    }
    @keyframes pulseGlow {
      0%, 100% { transform: scale(1); opacity: 1; }
      50% { transform: scale(1.35); opacity: 0.55; }
    }
    .sre-title {
      font-family: var(--font-serif);
      font-size: 19px;
      font-weight: 700;
      letter-spacing: -0.2px;
    }
    .sre-subtitle {
      font-size: 12px;
      color: var(--color-text-secondary);
    }
    .env-badge {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-family: var(--font-mono);
      font-size: 11px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 999px;
      background: rgba(215, 30, 40, 0.2);
      border: 1px solid #FFCD41;
      color: #FFCD41;
    }
    html[data-theme="light"] .env-badge {
      background: #FFF8E1;
      border-color: #D71E28;
      color: #9B111E;
    }
    .sre-controls-row {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }
    .sre-pill-btn {
      font-size: 11.5px;
      font-family: var(--font-mono);
      font-weight: 600;
      padding: 5px 11px;
      border-radius: 999px;
      border: 1px solid var(--color-border-secondary);
      background: rgba(38, 28, 32, 0.65);
      color: var(--color-text-secondary);
      cursor: pointer;
      transition: all 0.16s ease;
    }
    html[data-theme="light"] .sre-pill-btn {
      background: #F2ECE4;
    }
    .sre-pill-btn.active,
    .sre-pill-btn:hover {
      background: rgba(215, 30, 40, 0.25);
      color: #FFCD41;
      border-color: #FFCD41;
    }
    html[data-theme="light"] .sre-pill-btn.active,
    html[data-theme="light"] .sre-pill-btn:hover {
      background: #D71E28;
      color: #FFFFFF;
      border-color: #9B111E;
    }
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 10px;
      margin-bottom: 16px;
    }
    .kpi-card {
      padding: 12px 14px;
      border-radius: 12px;
      background: rgba(20, 14, 17, 0.72);
      border: 1px solid var(--color-border-tertiary);
      position: relative;
      overflow: hidden;
    }
    html[data-theme="light"] .kpi-card {
      background: #FAF7F2;
    }
    .kpi-card::after {
      content: "";
      position: absolute;
      inset: auto 0 0 0;
      height: 3px;
      background: linear-gradient(90deg, #D71E28, #FFCD41);
      opacity: 0.9;
    }
    .kpi-card.danger::after { background: linear-gradient(90deg, #D71E28, #FF6B72); }
    .kpi-card.success::after { background: linear-gradient(90deg, #10B981, #FFCD41); }
    .kpi-card.warning::after { background: linear-gradient(90deg, #FFCD41, #D71E28); }
    .kpi-label {
      font-size: 11px;
      color: var(--color-text-secondary);
      text-transform: uppercase;
      letter-spacing: 0.4px;
      margin-bottom: 4px;
    }
    .kpi-value {
      font-size: 21px;
      font-weight: 700;
      font-family: var(--font-mono);
      letter-spacing: -0.6px;
    }
    .kpi-delta {
      font-size: 11px;
      margin-top: 3px;
      color: var(--color-text-secondary);
    }
    .charts-row {
      display: grid;
      grid-template-columns: 1.55fr 1fr;
      gap: 12px;
      margin-bottom: 16px;
    }
    .chart-panel {
      background: rgba(20, 14, 17, 0.6);
      border: 1px solid var(--color-border-tertiary);
      border-radius: 12px;
      padding: 14px;
    }
    html[data-theme="light"] .chart-panel {
      background: #FAF7F2;
    }
    .chart-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      margin-bottom: 10px;
    }
    .chart-title {
      font-size: 13px;
      font-weight: 700;
    }
    .chart-legend {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 11px;
      color: var(--color-text-secondary);
    }
    .legend-dot {
      display: inline-block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      margin-right: 4px;
    }
    .sev-badge {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-family: var(--font-mono);
      font-size: 10.5px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 999px;
    }
    .sev-P1 { background: rgba(215, 30, 40, 0.22); color: #FF6B72; border: 1px solid rgba(215, 30, 40, 0.55); }
    .sev-P2 { background: rgba(255, 205, 65, 0.18); color: #FFCD41; border: 1px solid rgba(255, 205, 65, 0.45); }
    .sev-P3 { background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.35); }
    .sev-OK { background: rgba(16, 185, 129, 0.16); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.4); }
    .domain-tag {
      font-family: var(--font-mono);
      font-size: 10.5px;
      padding: 2px 7px;
      border-radius: 6px;
      background: rgba(255, 205, 65, 0.12);
      color: var(--color-text-secondary);
    }
    .alert-table-wrap {
      border: 1px solid var(--color-border-tertiary);
      border-radius: 12px;
      overflow: hidden;
      background: rgba(20, 14, 17, 0.52);
    }
    html[data-theme="light"] .alert-table-wrap {
      background: #FFFFFF;
    }
    table.sre-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12.5px;
    }
    table.sre-table th {
      text-align: left;
      padding: 10px 12px;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--color-text-secondary);
      background: rgba(215, 30, 40, 0.14);
      border-bottom: 1px solid var(--color-border-tertiary);
    }
    html[data-theme="light"] table.sre-table th {
      background: #F2ECE4;
    }
    table.sre-table td {
      padding: 10px 12px;
      border-bottom: 1px solid var(--color-border-tertiary);
      vertical-align: middle;
    }
    table.sre-table tr.alert-row {
      cursor: pointer;
      transition: background 0.15s ease;
    }
    table.sre-table tr.alert-row:hover,
    table.sre-table tr.alert-row.selected {
      background: rgba(255, 205, 65, 0.11);
    }
    .inspector-drawer {
      margin-top: 14px;
      padding: 14px 16px;
      border-radius: 12px;
      background: linear-gradient(135deg, rgba(215, 30, 40, 0.12), rgba(255, 205, 65, 0.08));
      border: 1px solid rgba(255, 205, 65, 0.45);
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .followup-strip {
      margin-top: 14px;
      padding-top: 12px;
      border-top: 1px dashed var(--color-border-tertiary);
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .followup-btn {
      font-size: 12px;
      font-weight: 600;
      padding: 6px 12px;
      border-radius: 8px;
      border: 1px solid rgba(255, 205, 65, 0.5);
      background: rgba(215, 30, 40, 0.2);
      color: #FFCD41;
      cursor: pointer;
    }
    html[data-theme="light"] .followup-btn {
      background: #FFF8E1;
      color: #9B111E;
      border-color: #D71E28;
    }
    .followup-btn:hover {
      background: rgba(215, 30, 40, 0.38);
    }
    .sim-bar {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 12px;
      padding: 12px 14px;
      border-radius: 12px;
      background: rgba(215, 30, 40, 0.1);
      border: 1px solid rgba(255, 205, 65, 0.38);
      margin-bottom: 16px;
    }
    .sim-control {
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .sim-label {
      display: flex;
      justify-content: space-between;
      font-size: 11.5px;
      font-weight: 600;
    }
    .region-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    .region-card {
      padding: 10px 12px;
      border-radius: 10px;
      background: rgba(20, 14, 17, 0.72);
      border: 1px solid var(--color-border-tertiary);
      cursor: pointer;
      transition: all 0.15s ease;
    }
    html[data-theme="light"] .region-card { background: #FFFFFF; }
    .region-card:hover { border-color: #FFCD41; }
    @media (max-width: 760px) {
      .kpi-grid { grid-template-columns: repeat(2, 1fr); }
      .charts-row { grid-template-columns: 1fr; }
      .sim-bar { grid-template-columns: 1fr; }
    }
  `;

  // ═══════════════════════════════════════════════════════════════════════════
  // SCENARIO 1: Top 10 Alerts Today — Network & Microsoft Intune Infrastructure
  // ═══════════════════════════════════════════════════════════════════════════
  function buildNetworkIntuneScenario() {
    return {
      id: "network-intune-alerts",
      title: "Top 10 Network & Intune Infrastructure Alerts",
      plan: {
        approach: "Correlate real-time NetOps (BGP, ExpressRoute, Branch SD-WAN, Anycast DNS) and Microsoft Intune MDM (SCEP, Conditional Access, Autopilot, StoreVision Branch Workstations) into an interactive Wells Fargo UpTimeEngineUI alert console.",
        technology: "OpenGenUI Fluidic SVG Splines + Live Alert Triage Matrix",
        key_elements: [
          "24h Network vs. Intune Alert Velocity Bezier Stream",
          "Subsystem Failure Domain & Severity Breakdown",
          "Interactive Top 10 Alerts Table impacting DXC Hogan Systems, Wells Fargo Vantage & StoreVision (SVP)",
        ],
      },
      introMarkdown:
        "Here is the **real-time fluidic telemetry view** of today's **Top 10 Alerts** across your **Core Network** and **Microsoft Intune** endpoint infrastructure. You can filter by domain or severity, click any alert row to inspect its 60-second telemetry stream, trigger simulated auto-remediation, or pivot directly to **DXC Hogan Systems**, **Wells Fargo Vantage**, or **StoreVision (SVP)**.",
      outroMarkdown:
        "**Executive Observation:** The **Intune SCEP Certificate Connector failure (`INT-8820`)** and **Core BGP Route Flap (`NET-9041`)** account for **64% of today's P1 impact**, affecting **StoreVision (SVP)** branch workstations and **Wells Fargo Vantage** mobile/cloud gateway latency.",
      activity: {
        initialHeight: 770,
        placeholderMessages: [
          "Correlating BGP & ExpressRoute flow logs",
          "Syncing Microsoft Intune MDM & StoreVision SVP workstation telemetry",
          "Streaming fluidic SVG spline curves",
          "Wiring interactive alert triage controls",
        ],
        css: SHARED_WIDGET_CSS,
        htmlChunks: [
          `<div class="sre-widget">
            <div class="sre-top-bar">
              <div class="sre-title-group">
                <span class="sre-eyebrow"><span class="sre-live-dot"></span> UPTIMEENGINEUI TELEMETRY · NETOPS + INTUNE MDM</span>
                <div class="sre-title">Top 10 Infrastructure Alerts Today — Network &amp; Intune</div>
                <div class="sre-subtitle">Simulated fluidic stream · Click any alert row to inspect live sparkline, acknowledge, or auto-remediate</div>
              </div>
              <div class="sre-controls-row">
                <button type="button" class="sre-pill-btn active" id="btn-live-wave" onclick="toggleWaveAnimation()">● Fluidic Stream: ON</button>
                <button type="button" class="sre-pill-btn" onclick="simulateAlertSpike()">⚡ Simulate Burst</button>
                <button type="button" class="sre-pill-btn" onclick="ackAllVisible()">✓ Ack Filtered</button>
              </div>
            </div>

            <div class="kpi-grid">
              <div class="kpi-card danger">
                <div class="kpi-label">Active Top Alerts</div>
                <div class="kpi-value" id="kpi-total-alerts">10 <span style="font-size:12px;color:#FF6B72;">(4 P1)</span></div>
                <div class="kpi-delta" id="kpi-ack-status">0 Acknowledged · 0 Remediated</div>
              </div>
              <div class="kpi-card warning">
                <div class="kpi-label">Network Core Health</div>
                <div class="kpi-value" id="kpi-net-health">96.4%</div>
                <div class="kpi-delta">BGP flap on <code>us-east-core-rtr02</code></div>
              </div>
              <div class="kpi-card">
                <div class="kpi-label">Intune &amp; SVP Compliance</div>
                <div class="kpi-value" id="kpi-intune-comp">94.2%</div>
                <div class="kpi-delta">4,820 SVP &amp; Mobile endpoints pending SCEP</div>
              </div>
              <div class="kpi-card success">
                <div class="kpi-label">Telemetry Ingestion</div>
                <div class="kpi-value" id="kpi-eps">142.8k/s</div>
                <div class="kpi-delta">Mean time to detect: <strong>11.4s</strong></div>
              </div>
            </div>`,
          `<div class="charts-row">
              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">24h Alert Velocity &amp; Anomaly Stream (Network vs. Intune)</span>
                  <div class="chart-legend">
                    <span><i class="legend-dot" style="background:#D71E28;"></i>Network Infra</span>
                    <span><i class="legend-dot" style="background:#FFCD41;"></i>Intune MDM</span>
                  </div>
                </div>
                <svg id="alert-velocity-svg" viewBox="0 0 560 190" style="width:100%;height:185px;display:block;overflow:visible;"></svg>
                <div id="chart-hover-readout" style="font-family:var(--font-mono);font-size:11px;color:var(--color-text-secondary);margin-top:4px;">
                  Hover over the fluidic curve to inspect hourly Network &amp; Intune alert bursts
                </div>
              </div>

              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Failure Domain Breakdown</span>
                  <span style="font-family:var(--font-mono);font-size:11px;color:#FFCD41;">Today (Top 10)</span>
                </div>
                <div id="domain-bars-container" style="display:flex;flex-direction:column;gap:9px;margin-top:6px;"></div>
              </div>
            </div>`,
          `<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;margin-bottom:10px;">
              <div class="sre-controls-row" id="domain-filter-pills">
                <button type="button" class="sre-pill-btn active" data-filter="ALL" onclick="setAlertFilter('ALL')">All (10)</button>
                <button type="button" class="sre-pill-btn" data-filter="Network" onclick="setAlertFilter('Network')">Network (5)</button>
                <button type="button" class="sre-pill-btn" data-filter="Intune" onclick="setAlertFilter('Intune')">Intune (5)</button>
                <button type="button" class="sre-pill-btn" data-filter="P1" onclick="setAlertFilter('P1')">Critical P1 (4)</button>
                <button type="button" class="sre-pill-btn" data-filter="P2" onclick="setAlertFilter('P2')">High P2 (4)</button>
              </div>
              <input type="search" id="alert-search-input" placeholder="Search Hogan, Vantage, SVP, BGP…" oninput="renderAlertsTable()" style="width:240px;" />
            </div>

            <div class="alert-table-wrap">
              <table class="sre-table">
                <thead>
                  <tr>
                    <th>ID / Severity</th>
                    <th>Domain &amp; Subsystem</th>
                    <th>Alert Summary &amp; Telemetry Metric</th>
                    <th>Affected Platform Scope</th>
                    <th>State / Action</th>
                  </tr>
                </thead>
                <tbody id="alerts-tbody"></tbody>
              </table>
            </div>

            <div id="alert-inspector" class="inspector-drawer"></div>

            <div class="followup-strip">
              <span style="font-size:11.5px;color:var(--color-text-secondary);">Interactive UpTimeEngineUI Bridge — launch platform monitoring in chat:</span>
              <div class="sre-controls-row">
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show me how high Doller value application DXC Hogan Systems is running')">🏛️ DXC Hogan Systems ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Wells Fargo Vantage application monitoring details')">☁️ Wells Fargo Vantage ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Branch Network Platform: StoreVision (SVP) health status')">🏦 StoreVision (SVP) Branch Health ↗</button>
              </div>
            </div>
          </div>`
        ],
        jsFunctions: `
          var ALERTS_DATA = [
            { id: "NET-9041", sev: "P1", domain: "Network", sub: "Core BGP Routing", title: "BGP Peer Oscillation on us-east-core-rtr02 (ASN 65104)", metric: "14.2% packet loss · 19 flaps/min", scope: "DXC Hogan Mainframe Gateway", time: "2m ago", status: "Active", rca: "Hold-timer mismatch after carrier maintenance on transit link xe-0/1/0 impacting DXC Hogan CICS gateway.", spark: [12, 18, 25, 64, 88, 95, 78, 92, 85, 90] },
            { id: "INT-8820", sev: "P1", domain: "Intune", sub: "SCEP Certificate Connector", title: "NDES / SCEP Certificate Renewal Failure (Error 0x87D00281)", metric: "4,820 endpoints failing 802.1X Wi-Fi", scope: "StoreVision (SVP) Branch Workstations", time: "5m ago", status: "Active", rca: "Intune Certificate Connector pool exhausted TLS worker threads renewing StoreVision (SVP) branch workstation certs.", spark: [20, 32, 48, 70, 84, 89, 94, 96, 91, 95] },
            { id: "NET-9038", sev: "P1", domain: "Network", sub: "Azure ExpressRoute", title: "ExpressRoute Circuit ER-CHARLOTTE-01 RTT Latency Spike", metric: "RTT 188ms (baseline 12ms) · 98% QoS", scope: "Wells Fargo Vantage Cloud Mesh", time: "9m ago", status: "Active", rca: "Unthrottled Intune Win32 OS image replication saturating ExpressRoute AF21 queue used by Vantage microservices.", spark: [14, 15, 22, 45, 76, 88, 84, 82, 79, 85] },
            { id: "INT-8814", sev: "P1", domain: "Intune", sub: "Conditional Access", title: "Conditional Access Evaluation Timeout (CA-ZeroTrust-Prod)", metric: "4.6s token latency · 18% retry rate", scope: "Wells Fargo Vantage Mobile & Web", time: "14m ago", status: "Active", rca: "Device compliance lookup delayed by stale Defender signal pipeline during Vantage commercial mobile sign-on.", spark: [18, 24, 39, 62, 77, 81, 74, 79, 73, 76] },
            { id: "NET-9029", sev: "P2", domain: "Network", sub: "Branch SD-WAN Fabric", title: "IPsec Tunnel Rekeying Loop on svp-west-gw04", metric: "Jitter 46ms · Teller session lag", scope: "StoreVision (SVP) West Coast Branches", time: "21m ago", status: "Active", rca: "IKEv2 SA lifetime mismatch (3600s vs 28800s) following automated branch firewall policy push.", spark: [25, 28, 42, 55, 63, 58, 61, 59, 54, 57] },
            { id: "INT-8799", sev: "P2", domain: "Intune", sub: "Windows Autopilot", title: "Autopilot Enrollment Status Page (ESP) Timeout", metric: "162 teller workstations stuck at setup", scope: "StoreVision (SVP) Branch Workstations", time: "27m ago", status: "Active", rca: "Required SVP peripheral driver package waiting on unreachable internal CRL distribution point.", spark: [15, 22, 35, 48, 52, 56, 54, 51, 53, 50] },
            { id: "NET-9015", sev: "P2", domain: "Network", sub: "Core Anycast DNS", title: "DNS Resolver vip-dns-01 SERVFAIL Surge", metric: "3,420 SERVFAIL/min · +340% spike", scope: "Vantage Microservices Service Discovery", time: "34m ago", status: "Active", rca: "Upstream forwarding timeout to internal DNS controllers over congested East transit.", spark: [10, 14, 28, 60, 72, 65, 58, 52, 49, 55] },
            { id: "INT-8782", sev: "P2", domain: "Intune", sub: "Defender Compliance", title: "Defender for Endpoint Sensor Telemetry Sync Lag", metric: "1,190 branch PCs marked Non-Compliant", scope: "StoreVision (SVP) Win11-Ring1", time: "41m ago", status: "Active", rca: "Intune compliance evaluation queue backlog after bulk ASR rule update across retail branches.", spark: [22, 30, 44, 51, 55, 53, 48, 46, 45, 47] },
            { id: "NET-9004", sev: "P3", domain: "Network", sub: "Perimeter Firewall", title: "Palo Alto PA-5250 fw-dmz-01 Session Table at 86%", metric: "1.72M / 2.0M active sessions", scope: "DXC Hogan & Vantage API Egress", time: "53m ago", status: "Active", rca: "Elevated ephemeral TCP sessions from cloud proxy telemetry agents.", spark: [40, 45, 52, 60, 68, 74, 79, 83, 85, 86] },
            { id: "INT-8765", sev: "P3", domain: "Intune", sub: "Win32 App Delivery", title: "Delivery Optimization CDN Throttling (SVP-Agent-4.12)", metric: "Download rate capped at 18 Mbps", scope: "Midwest Branch Workstations", time: "1h ago", status: "Active", rca: "Peer-to-peer DO cache miss ratio at 72% across subnet-isolated branch workstations.", spark: [18, 25, 33, 41, 45, 44, 42, 39, 40, 38] }
          ];

          var currentFilter = "ALL";
          var selectedAlertId = "NET-9041";
          var wavePhase = 0;
          var waveRunning = true;
          var netSeries = [18, 22, 19, 25, 31, 48, 62, 54, 71, 88, 94, 82];
          var intuneSeries = [14, 17, 21, 28, 36, 42, 58, 67, 79, 85, 91, 86];
          var hoursLabels = ["00:00", "02:00", "04:00", "06:00", "08:00", "10:00", "12:00", "14:00", "16:00", "18:00", "20:00", "Now"];

          function buildSmoothPath(pts) {
            if (!pts.length) return "";
            var d = "M " + pts[0][0].toFixed(1) + " " + pts[0][1].toFixed(1);
            for (var i = 0; i < pts.length - 1; i++) {
              var p0 = pts[i];
              var p1 = pts[i + 1];
              var cx = (p0[0] + p1[0]) / 2;
              d += " C " + cx.toFixed(1) + " " + p0[1].toFixed(1) + ", " + cx.toFixed(1) + " " + p1[1].toFixed(1) + ", " + p1[0].toFixed(1) + " " + p1[1].toFixed(1);
            }
            return d;
          }

          function renderVelocityChart() {
            var svg = document.getElementById("alert-velocity-svg");
            if (!svg) return;
            var w = 560, h = 160, padL = 28, padR = 14, padT = 14, padB = 24;
            var plotW = w - padL - padR;
            var plotH = h - padT - padB;

            var netPts = netSeries.map(function(v, i) {
              var jitter = waveRunning ? Math.sin(wavePhase + i * 0.65) * 4.2 : 0;
              var val = Math.max(8, Math.min(100, v + jitter));
              var x = padL + (i / (netSeries.length - 1)) * plotW;
              var y = padT + plotH - (val / 100) * plotH;
              return [x, y, Math.round(val)];
            });

            var intPts = intuneSeries.map(function(v, i) {
              var jitter = waveRunning ? Math.cos(wavePhase * 0.9 + i * 0.55) * 4.0 : 0;
              var val = Math.max(8, Math.min(100, v + jitter));
              var x = padL + (i / (intuneSeries.length - 1)) * plotW;
              var y = padT + plotH - (val / 100) * plotH;
              return [x, y, Math.round(val)];
            });

            var netLine = buildSmoothPath(netPts);
            var netArea = netLine + " L " + netPts[netPts.length - 1][0] + " " + (padT + plotH) + " L " + netPts[0][0] + " " + (padT + plotH) + " Z";
            var intLine = buildSmoothPath(intPts);
            var intArea = intLine + " L " + intPts[intPts.length - 1][0] + " " + (padT + plotH) + " L " + intPts[0][0] + " " + (padT + plotH) + " Z";

            var gridHtml = "";
            for (var g = 0; g <= 3; g++) {
              var gy = padT + (g / 3) * plotH;
              var labelVal = Math.round(100 - (g / 3) * 100);
              gridHtml += '<line x1="' + padL + '" y1="' + gy + '" x2="' + (w - padR) + '" y2="' + gy + '" stroke="rgba(255,205,65,0.12)" stroke-dasharray="3 3" />';
              gridHtml += '<text x="2" y="' + (gy + 4) + '" fill="#8F8286" font-size="10" font-family="monospace">' + labelVal + '</text>';
            }

            var xLabels = hoursLabels.map(function(lbl, i) {
              if (i % 2 !== 0 && i !== hoursLabels.length - 1) return "";
              var x = padL + (i / (hoursLabels.length - 1)) * plotW;
              return '<text x="' + x + '" y="' + (h + 12) + '" text-anchor="middle" fill="#8F8286" font-size="10" font-family="monospace">' + lbl + '</text>';
            }).join("");

            var dotsHtml = netPts.map(function(p, idx) {
              var ip = intPts[idx];
              return '<g class="node" onmouseenter="showHourReadout(' + idx + ',' + p[2] + ',' + ip[2] + ')">' +
                '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3.5" fill="#D71E28" />' +
                '<circle cx="' + ip[0].toFixed(1) + '" cy="' + ip[1].toFixed(1) + '" r="3.5" fill="#FFCD41" />' +
                '<rect x="' + (p[0] - 16) + '" y="' + padT + '" width="32" height="' + plotH + '" fill="transparent" />' +
              '</g>';
            }).join("");

            svg.innerHTML =
              '<defs>' +
                '<linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">' +
                  '<stop offset="0%" stop-color="#D71E28" stop-opacity="0.44"/>' +
                  '<stop offset="100%" stop-color="#D71E28" stop-opacity="0.0"/>' +
                '</linearGradient>' +
                '<linearGradient id="intGrad" x1="0" y1="0" x2="0" y2="1">' +
                  '<stop offset="0%" stop-color="#FFCD41" stop-opacity="0.34"/>' +
                  '<stop offset="100%" stop-color="#FFCD41" stop-opacity="0.0"/>' +
                '</linearGradient>' +
              '</defs>' +
              gridHtml +
              '<path d="' + netArea + '" fill="url(#netGrad)" />' +
              '<path d="' + intArea + '" fill="url(#intGrad)" />' +
              '<path d="' + netLine + '" fill="none" stroke="#D71E28" stroke-width="2.5" />' +
              '<path d="' + intLine + '" fill="none" stroke="#FFCD41" stroke-width="2.4" />' +
              dotsHtml +
              xLabels;
          }

          window.showHourReadout = function(idx, netVal, intVal) {
            var el = document.getElementById("chart-hover-readout");
            if (!el) return;
            el.innerHTML = 'Window <strong>' + hoursLabels[idx] + '</strong> · Network Alerts Index: <strong style="color:#FF6B72">' + netVal + '</strong> · Intune MDM Index: <strong style="color:#FFCD41">' + intVal + '</strong>';
          };

          function renderDomainBars() {
            var container = document.getElementById("domain-bars-container");
            if (!container) return;
            var domains = [
              { label: "StoreVision (SVP) Intune SCEP Certs", count: "4,820 branch PCs", pct: 92, color: "#D71E28" },
              { label: "DXC Hogan BGP & Mainframe Transit", count: "2 P1 circuits", pct: 84, color: "#FFCD41" },
              { label: "Wells Fargo Vantage Cloud/Mobile CA", count: "18% token retry", pct: 72, color: "#F59E0B" },
              { label: "Branch SD-WAN & Perimeter Firewalls", count: "1.72M sessions", pct: 64, color: "#38bdf8" },
              { label: "Autopilot ESP & Win32 SVP Agent", count: "162 workstations", pct: 52, color: "#10b981" }
            ];
            container.innerHTML = domains.map(function(d) {
              return '<div>' +
                '<div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px;">' +
                  '<span>' + d.label + '</span>' +
                  '<span style="font-family:var(--font-mono);color:var(--color-text-secondary);">' + d.count + '</span>' +
                '</div>' +
                '<div style="height:7px;background:rgba(255,205,65,0.12);border-radius:999px;overflow:hidden;">' +
                  '<div style="width:' + d.pct + '%;height:100%;background:' + d.color + ';border-radius:999px;transition:width 0.4s ease;"></div>' +
                '</div>' +
              '</div>';
            }).join("");
          }

          window.setAlertFilter = function(filter) {
            currentFilter = filter;
            var btns = document.querySelectorAll("#domain-filter-pills button");
            btns.forEach(function(b) {
              b.classList.toggle("active", b.getAttribute("data-filter") === filter);
            });
            renderAlertsTable();
          };

          window.renderAlertsTable = function() {
            var tbody = document.getElementById("alerts-tbody");
            if (!tbody) return;
            var q = (document.getElementById("alert-search-input")?.value || "").toLowerCase();
            var filtered = ALERTS_DATA.filter(function(a) {
              var matchFilter =
                currentFilter === "ALL" ||
                a.domain === currentFilter ||
                a.sev === currentFilter;
              var matchQuery =
                !q ||
                a.id.toLowerCase().indexOf(q) !== -1 ||
                a.title.toLowerCase().indexOf(q) !== -1 ||
                a.sub.toLowerCase().indexOf(q) !== -1 ||
                a.scope.toLowerCase().indexOf(q) !== -1;
              return matchFilter && matchQuery;
            });

            tbody.innerHTML = filtered.map(function(a) {
              var isSel = a.id === selectedAlertId;
              var badgeClass = a.status === "Remediated" ? "sev-OK" : ("sev-" + a.sev);
              return '<tr class="alert-row ' + (isSel ? 'selected' : '') + '" onclick="selectAlertRow(\\'' + a.id + '\\')">' +
                '<td><span class="sev-badge ' + badgeClass + '">' + a.sev + '</span> <strong style="font-family:var(--font-mono);margin-left:4px;">' + a.id + '</strong></td>' +
                '<td><span class="domain-tag">' + a.domain + '</span><div style="font-size:11px;color:var(--color-text-secondary);margin-top:2px;">' + a.sub + '</div></td>' +
                '<td><div style="font-weight:600;">' + a.title + '</div><div style="font-family:var(--font-mono);font-size:11px;color:#FFCD41;">' + a.metric + '</div></td>' +
                '<td><div><strong>' + a.scope + '</strong></div><div style="font-size:11px;color:var(--color-text-secondary);">' + a.time + '</div></td>' +
                '<td><span class="sev-badge ' + (a.status === 'Active' ? 'sev-P2' : 'sev-OK') + '">' + a.status + '</span></td>' +
              '</tr>';
            }).join("");

            updateKpiCounters();
            renderInspector();
            if (window.__reportOguiHeight) window.__reportOguiHeight();
          };

          window.selectAlertRow = function(id) {
            selectedAlertId = id;
            renderAlertsTable();
          };

          function renderInspector() {
            var box = document.getElementById("alert-inspector");
            if (!box) return;
            var item = ALERTS_DATA.find(function(a) { return a.id === selectedAlertId; }) || ALERTS_DATA[0];
            if (!item) return;

            var sparkPts = item.spark.map(function(v, i) {
              var x = 10 + (i / (item.spark.length - 1)) * 200;
              var y = 42 - (v / 100) * 34;
              return x.toFixed(1) + "," + y.toFixed(1);
            }).join(" ");

            box.innerHTML =
              '<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;">' +
                '<div>' +
                  '<span class="sev-badge sev-' + item.sev + '">' + item.sev + '</span> ' +
                  '<strong style="font-size:14px;margin-left:6px;">[' + item.id + '] ' + item.title + '</strong>' +
                  '<span style="font-family:var(--font-mono);font-size:11px;color:var(--color-text-secondary);margin-left:8px;">State: ' + item.status + '</span>' +
                '</div>' +
                '<div class="sre-controls-row">' +
                  '<button type="button" onclick="ackAlert(\\'' + item.id + '\\')">✓ Acknowledge</button>' +
                  '<button type="button" onclick="remediateAlert(\\'' + item.id + '\\')" style="border-color:#10b981;color:#34d399;">⚡ Run Auto-Remediation</button>' +
                  '<button type="button" onclick="sendFollowUp(\\'Deep-dive root cause and execute remediation runbook for alert ' + item.id + ' (' + item.scope + ')\\')" style="border-color:#FFCD41;color:#FFCD41;">Ask AI Runbook in Chat ↗</button>' +
                '</div>' +
              '</div>' +
              '<div style="display:grid;grid-template-columns:1fr auto;gap:14px;align-items:center;">' +
                '<div style="font-size:12.5px;color:var(--color-text-secondary);">' +
                  '<strong style="color:var(--color-text-primary);">Root-Cause Telemetry Diagnosis (' + item.scope + '):</strong> ' + item.rca +
                '</div>' +
                '<div style="background:rgba(16,11,13,0.75);padding:6px 10px;border-radius:8px;border:1px solid var(--color-border-tertiary);">' +
                  '<div style="font-size:10px;font-family:var(--font-mono);color:#FFCD41;">LIVE 60s ANOMALY WAVE</div>' +
                  '<svg width="220" height="46" viewBox="0 0 220 46">' +
                    '<polyline fill="none" stroke="#FFCD41" stroke-width="2.2" points="' + sparkPts + '" />' +
                  '</svg>' +
                '</div>' +
              '</div>';
          }

          window.ackAlert = function(id) {
            var item = ALERTS_DATA.find(function(a) { return a.id === id; });
            if (item && item.status === "Active") item.status = "Acknowledged";
            renderAlertsTable();
          };

          window.remediateAlert = function(id) {
            var item = ALERTS_DATA.find(function(a) { return a.id === id; });
            if (!item) return;
            item.status = "Remediated";
            item.metric = "Stabilized · Auto-remediated via Playbook";
            item.spark = [80, 65, 48, 30, 22, 16, 12, 10, 9, 8];
            renderAlertsTable();
          };

          window.ackAllVisible = function() {
            ALERTS_DATA.forEach(function(a) {
              if (currentFilter === "ALL" || a.domain === currentFilter || a.sev === currentFilter) {
                if (a.status === "Active") a.status = "Acknowledged";
              }
            });
            renderAlertsTable();
          };

          window.simulateAlertSpike = function() {
            netSeries = netSeries.map(function(v) { return Math.min(99, v + Math.round(Math.random() * 16)); });
            intuneSeries = intuneSeries.map(function(v) { return Math.min(99, v + Math.round(Math.random() * 14)); });
            renderVelocityChart();
          };

          window.toggleWaveAnimation = function() {
            waveRunning = !waveRunning;
            var btn = document.getElementById("btn-live-wave");
            if (btn) {
              btn.textContent = waveRunning ? "● Fluidic Stream: ON" : "○ Fluidic Stream: PAUSED";
              btn.classList.toggle("active", waveRunning);
            }
          };

          function updateKpiCounters() {
            var acked = ALERTS_DATA.filter(function(a) { return a.status === "Acknowledged"; }).length;
            var fixed = ALERTS_DATA.filter(function(a) { return a.status === "Remediated"; }).length;
            var activeCount = ALERTS_DATA.length - fixed;
            var elTotal = document.getElementById("kpi-total-alerts");
            var elAck = document.getElementById("kpi-ack-status");
            var elNet = document.getElementById("kpi-net-health");
            var elInt = document.getElementById("kpi-intune-comp");
            if (elTotal) elTotal.innerHTML = activeCount + ' <span style="font-size:12px;color:#FFCD41;">/ 10 Today</span>';
            if (elAck) elAck.textContent = acked + " Acknowledged · " + fixed + " Remediated";
            if (elNet) elNet.textContent = (96.4 + fixed * 0.35).toFixed(1) + "%";
            if (elInt) elInt.textContent = (94.2 + fixed * 0.55).toFixed(1) + "%";
          }

          window.sendFollowUp = function(text) {
            if (window.Websandbox && window.Websandbox.connection && window.Websandbox.connection.remote) {
              window.Websandbox.connection.remote.sendPrompt({ text: text });
            }
          };
        `,
        jsExpressions: [
          `renderVelocityChart();`,
          `renderDomainBars();`,
          `renderAlertsTable();`,
          `setInterval(function() {
            if (!waveRunning) return;
            wavePhase += 0.35;
            renderVelocityChart();
            var epsEl = document.getElementById("kpi-eps");
            if (epsEl) {
              var jitter = (142.4 + Math.sin(wavePhase) * 3.8).toFixed(1);
              epsEl.textContent = jitter + "k/s";
            }
          }, 900);`
        ],
      },
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SCENARIO 2: High Dollar-Value Application — DXC Hogan Systems
  //             + Integrated Enterprise Switcher (DXC Hogan, Wells Fargo Vantage, StoreVision SVP)
  // ═══════════════════════════════════════════════════════════════════════════
  function buildDXCHoganScenario() {
    return {
      id: "dxc-hogan-systems",
      title: "High Dollar-Value Application — DXC Hogan Systems & Enterprise Core",
      plan: {
        approach: "Render an interactive Wells Fargo executive SRE command center for the High Dollar-Value Application 'DXC Hogan Systems' alongside 'Wells Fargo Vantage' (Cloud / Microservices / Mobile) and 'Branch Network Platform: StoreVision (SVP)' (Enterprise Branch Workstations).",
        technology: "OpenGenUI Core Banking Telemetry + Live Settlement & Golden Signals Simulator",
        key_elements: [
          "DXC Hogan Systems Core Ledger & Settlement Volume ($4.85M/min · 42,800 CICS TPS)",
          "Wells Fargo Vantage (Cloud / Microservices / Mobile) & StoreVision (SVP) Cross-Platform Matrix",
          "Interactive Transaction Surge, Mainframe MIPS / Pod Scaling & Multi-Region Failover Simulator",
        ],
      },
      introMarkdown:
        "Here is the **live fluidic performance & financial telemetry** for your High Dollar-Value Application **DXC Hogan Systems** (`$291M/hr` / `$4.85M/min` core deposit, ACH, Wire & Zelle settlement), integrated with **Wells Fargo Vantage** (`Cloud / Microservices / Mobile`) and **Branch Network Platform: StoreVision (SVP)** (`Enterprise Branch Workstations`). Use the platform switcher or sliders below to simulate load and inspect real-time health.",
      outroMarkdown:
        "**Executive SRE Summary:** **DXC Hogan Systems** is maintaining a **99.996% SLA** (`6.8ms` mainframe CICS response). **Wells Fargo Vantage** (`Cloud / Microservices / Mobile`) is absorbing commercial wire traffic at `28.4ms` p99 latency, while **StoreVision (SVP)** (`Enterprise Branch Workstations`) is at `98.8%` workstation availability across 4,720 branches.",
      activity: {
        initialHeight: 775,
        placeholderMessages: [
          "Polling DXC Hogan Systems CICS/IMS & Z-Series settlement channels",
          "Aggregating Wells Fargo Vantage Cloud / Microservices / Mobile golden signals",
          "Syncing StoreVision (SVP) Enterprise Branch Workstations health",
          "Rendering fluidic dollar throughput vs. p99 latency splines",
        ],
        css: SHARED_WIDGET_CSS,
        htmlChunks: [
          `<div class="sre-widget">
            <div class="sre-top-bar">
              <div class="sre-title-group">
                <span class="sre-eyebrow"><span class="sre-live-dot"></span> WELLS FARGO TIER-0 CORE · HIGH DOLLAR-VALUE APPLICATION</span>
                <div class="sre-title" id="hogan-main-title">DXC Hogan Systems — Core Banking &amp; Settlement Engine</div>
                <div class="sre-subtitle" id="hogan-main-sub">Primary Environment: Mainframe Z-Series / CICS / Core Deposit &amp; Settlement System of Record</div>
              </div>
              <div class="sre-controls-row" id="app-selector-pills">
                <button type="button" class="sre-pill-btn active" data-app="HOGAN" onclick="selectApp('HOGAN')">🏛️ DXC Hogan Systems ($291M/hr)</button>
                <button type="button" class="sre-pill-btn" data-app="VANTAGE" onclick="selectApp('VANTAGE')">☁️ Wells Fargo Vantage (Cloud/Microservices/Mobile)</button>
                <button type="button" class="sre-pill-btn" data-app="SVP" onclick="selectApp('SVP')">🏦 StoreVision SVP (Branch Workstations)</button>
              </div>
            </div>

            <div class="kpi-grid">
              <div class="kpi-card success">
                <div class="kpi-label" id="fin-lbl-1">Live Dollar Settlement</div>
                <div class="kpi-value" id="fin-kpi-rate" style="color:#FFCD41;">$4,850,000/m</div>
                <div class="kpi-delta" id="fin-kpi-session">$80,833/sec settled · 42,800 TPS</div>
              </div>
              <div class="kpi-card">
                <div class="kpi-label">Platform Availability SLA</div>
                <div class="kpi-value" id="fin-kpi-sla">99.996%</div>
                <div class="kpi-delta" id="fin-kpi-apdex">Env: Mainframe CICS / Z-Series</div>
              </div>
              <div class="kpi-card warning">
                <div class="kpi-label">p99 Response Latency</div>
                <div class="kpi-value" id="fin-kpi-lat">6.8 ms</div>
                <div class="kpi-delta" id="fin-kpi-err">Error rate: 0.004% (SLO healthy)</div>
              </div>
              <div class="kpi-card danger">
                <div class="kpi-label">Dollar Value Protected</div>
                <div class="kpi-value" id="fin-kpi-risk" style="color:#34d399;">99.99%</div>
                <div class="kpi-delta" id="fin-kpi-shield">GDPS Sysplex &amp; Multi-Region: ACTIVE</div>
              </div>
            </div>`,
          `<div class="sim-bar">
              <div class="sim-control">
                <div class="sim-label">
                  <span>Transaction Volume Multiplier</span>
                  <span id="lbl-load-mult" style="font-family:var(--font-mono);color:#FFCD41;">100% (Nominal)</span>
                </div>
                <input type="range" id="rng-load" min="60" max="220" value="100" oninput="updateHighDollarSim()" />
              </div>
              <div class="sim-control">
                <div class="sim-label">
                  <span>Compute Capacity (MIPS / K8s Pods)</span>
                  <span id="lbl-pods" style="font-family:var(--font-mono);color:#34d399;">100% Provisioned</span>
                </div>
                <input type="range" id="rng-pods" min="60" max="180" value="100" oninput="updateHighDollarSim()" />
              </div>
              <div class="sim-control" style="justify-content:center;">
                <div class="sim-label"><span>High-Availability Shield</span><span id="lbl-failover" style="font-family:var(--font-mono);color:#34d399;">Active-Active</span></div>
                <div style="display:flex;gap:6px;">
                  <button type="button" class="sre-pill-btn active" id="btn-failover" onclick="toggleFailoverShield()" style="width:100%;">🛡️ Sysplex / Cloud Auto-Failover: ON</button>
                </div>
              </div>
            </div>

            <div class="charts-row">
              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title" id="chart-curve-title">Real-Time Settlement Throughput vs. p99 Latency</span>
                  <div class="chart-legend">
                    <span><i class="legend-dot" style="background:#FFCD41;"></i>Volume / Health</span>
                    <span><i class="legend-dot" style="background:#D71E28;"></i>p99 Latency</span>
                  </div>
                </div>
                <svg id="revenue-latency-svg" viewBox="0 0 560 185" style="width:100%;height:180px;display:block;"></svg>
              </div>

              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Core Hubs &amp; Subsystem Mesh</span>
                  <span style="font-family:var(--font-mono);font-size:11px;color:var(--color-text-secondary);">Click hub to optimize</span>
                </div>
                <div class="region-grid" id="region-cards-grid"></div>
              </div>
            </div>`,
          `<div class="alert-table-wrap">
              <table class="sre-table">
                <thead>
                  <tr>
                    <th>Enterprise Application / Platform</th>
                    <th>Primary Environment</th>
                    <th>Dollar / Fleet Scale</th>
                    <th>Throughput / Online</th>
                    <th>p99 Latency</th>
                    <th>Health Status</th>
                  </tr>
                </thead>
                <tbody id="tier0-tbody"></tbody>
              </table>
            </div>

            <div class="followup-strip">
              <span style="font-size:11.5px;color:var(--color-text-secondary);">Drill down into dedicated platform dashboards in chat:</span>
              <div class="sre-controls-row">
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Wells Fargo Vantage application monitoring details')">☁️ Open Wells Fargo Vantage Dashboard ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Branch Network Platform: StoreVision (SVP) health status')">🏦 Open StoreVision (SVP) Branch Dashboard ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show live incident blast-radius and dependency topology')">🕸️ View Blast Radius Topology ↗</button>
              </div>
            </div>
          </div>`
        ],
        jsFunctions: `
          var APPS = {
            HOGAN: {
              name: "DXC Hogan Systems — Core Banking & Settlement Engine",
              env: "Mainframe Z-Series / CICS / Core Deposit & Settlement (CIS · IDS · PAS)",
              hourly: 291000000,
              baseLat: 6.8,
              baseTps: 42800,
              sla: 99.996,
              baseRevSeries: [38.2, 39.5, 41.0, 42.4, 43.8, 44.2, 43.1, 43.9, 44.5, 44.1],
              baseLatSeries: [18, 19, 20, 22, 26, 24, 21, 20, 19, 20]
            },
            VANTAGE: {
              name: "Wells Fargo Vantage — Commercial & Corporate Banking",
              env: "Cloud / Microservices / Mobile (Kubernetes · Apigee API · iOS & Android)",
              hourly: 142000000,
              baseLat: 28.4,
              baseTps: 19600,
              sla: 99.985,
              baseRevSeries: [26.0, 27.4, 29.1, 31.2, 33.0, 34.5, 32.8, 33.9, 35.1, 34.6],
              baseLatSeries: [32, 35, 38, 45, 54, 48, 41, 39, 37, 38]
            },
            SVP: {
              name: "Branch Network Platform: StoreVision (SVP)",
              env: "Enterprise Branch Workstations (4,720 Branches · 38,450 Teller/Banker PCs)",
              hourly: 64000000,
              baseLat: 42.0,
              baseTps: 14200,
              sla: 98.840,
              baseRevSeries: [22.0, 23.5, 25.0, 26.8, 28.2, 27.5, 27.9, 28.4, 28.8, 28.5],
              baseLatSeries: [40, 42, 48, 58, 66, 60, 52, 49, 47, 46]
            }
          };

          var REGIONS = [
            { id: "charlotte", name: "Charlotte Core Sysplex (HOGAN-A)", share: "$168M/hr CICS", rtt: 5, status: "Optimal GDPS", color: "#34d399" },
            { id: "minneapolis", name: "Minneapolis Core Sysplex (HOGAN-B)", share: "$123M/hr CICS", rtt: 7, status: "Active Mirror", color: "#34d399" },
            { id: "vantagecloud", name: "Vantage Cloud / Mobile Mesh", share: "Cloud/Microservices", rtt: 28, status: "Auto-Scaled", color: "#FFCD41" },
            { id: "svpbranch", name: "StoreVision (SVP) Branch Fleet", share: "38,450 Workstations", rtt: 42, status: "98.8% Online", color: "#38bdf8" }
          ];

          var selectedAppKey = "HOGAN";
          var failoverActive = true;
          var tickPhase = 0;

          window.selectApp = function(key) {
            selectedAppKey = key;
            document.querySelectorAll("#app-selector-pills button").forEach(function(b) {
              b.classList.toggle("active", b.getAttribute("data-app") === key);
            });
            updateHighDollarSim();
          };

          window.toggleFailoverShield = function() {
            failoverActive = !failoverActive;
            var btn = document.getElementById("btn-failover");
            var lbl = document.getElementById("lbl-failover");
            if (btn) {
              btn.textContent = failoverActive ? "🛡️ Sysplex / Cloud Auto-Failover: ON" : "⚠️ Auto-Failover Shield: OFF";
              btn.classList.toggle("active", failoverActive);
            }
            if (lbl) {
              lbl.textContent = failoverActive ? "Active-Active" : "Single-Path";
              lbl.style.color = failoverActive ? "#34d399" : "#FF6B72";
            }
            updateHighDollarSim();
          };

          window.rebalanceRegion = function(regionId) {
            REGIONS.forEach(function(r) {
              if (r.id === regionId) {
                r.status = "Optimized ✓";
                r.rtt = Math.max(4, r.rtt - 6);
                r.color = "#34d399";
              }
            });
            updateHighDollarSim();
          };

          window.updateHighDollarSim = function() {
            var app = APPS[selectedAppKey] || APPS.HOGAN;
            var loadPct = parseInt(document.getElementById("rng-load")?.value || "100", 10);
            var capPct = parseInt(document.getElementById("rng-pods")?.value || "100", 10);

            document.getElementById("hogan-main-title").textContent = app.name;
            document.getElementById("hogan-main-sub").textContent = "Primary Environment: " + app.env;

            document.getElementById("lbl-load-mult").textContent = loadPct + "% (" + (loadPct > 140 ? "Peak Window" : loadPct < 80 ? "Off-Peak" : "Nominal") + ")";
            document.getElementById("lbl-pods").textContent = capPct + "% Capacity";

            var stressRatio = (loadPct / 100) / (capPct / 100);
            var failoverFactor = failoverActive ? 1.0 : 1.48;
            var computedLat = app.baseLat * Math.pow(stressRatio, 1.1) * failoverFactor;
            var errRate = Math.max(0.004, (stressRatio > 1.2 ? (stressRatio - 1.05) * 0.25 : 0.006) * failoverFactor);
            var sla = Math.max(97.5, app.sla - errRate * 0.2);
            var perMinActual = (app.hourly / 60) * (loadPct / 100);

            document.getElementById("fin-kpi-rate").textContent = "$" + Math.round(perMinActual).toLocaleString() + "/m";
            document.getElementById("fin-kpi-session").textContent = "$" + Math.round(perMinActual / 60).toLocaleString() + "/sec · " + Math.round(app.baseTps * (loadPct / 100)).toLocaleString() + " TPS";
            document.getElementById("fin-kpi-sla").textContent = sla.toFixed(3) + "%";
            document.getElementById("fin-kpi-apdex").textContent = app.env.split("(")[0].trim();
            document.getElementById("fin-kpi-lat").textContent = computedLat.toFixed(1) + " ms";
            document.getElementById("fin-kpi-err").textContent = "Error rate: " + errRate.toFixed(3) + "%";
            document.getElementById("fin-kpi-risk").textContent = (100 - errRate).toFixed(3) + "%";

            renderRevenueChart(app, loadPct / 100, computedLat / app.baseLat);
            renderRegions();
            renderTier0Table(loadPct / 100, stressRatio * failoverFactor);
            if (window.__reportOguiHeight) window.__reportOguiHeight();
          };

          function renderRevenueChart(app, loadMult, latMult) {
            var svg = document.getElementById("revenue-latency-svg");
            if (!svg) return;
            var w = 560, h = 165, padL = 34, padR = 30, padT = 14, padB = 22;
            var plotW = w - padL - padR;
            var plotH = h - padT - padB;

            var revPts = app.baseRevSeries.map(function(v, i) {
              var wave = Math.sin(tickPhase + i * 0.6) * 0.8;
              var val = (v * loadMult) + wave;
              var x = padL + (i / (app.baseRevSeries.length - 1)) * plotW;
              var y = padT + plotH - Math.min(1, val / 75) * plotH;
              return [x, y];
            });

            var latPts = app.baseLatSeries.map(function(v, i) {
              var wave = Math.cos(tickPhase + i * 0.55) * 2.0;
              var val = (v * latMult) + wave;
              var x = padL + (i / (app.baseLatSeries.length - 1)) * plotW;
              var y = padT + plotH - Math.min(1, val / 110) * plotH;
              return [x, y];
            });

            function smooth(pts) {
              var d = "M " + pts[0][0].toFixed(1) + " " + pts[0][1].toFixed(1);
              for (var i = 0; i < pts.length - 1; i++) {
                var cx = (pts[i][0] + pts[i + 1][0]) / 2;
                d += " C " + cx.toFixed(1) + " " + pts[i][1].toFixed(1) + ", " + cx.toFixed(1) + " " + pts[i + 1][1].toFixed(1) + ", " + pts[i + 1][0].toFixed(1) + " " + pts[i + 1][1].toFixed(1);
              }
              return d;
            }

            var revLine = smooth(revPts);
            var revArea = revLine + " L " + revPts[revPts.length - 1][0] + " " + (padT + plotH) + " L " + revPts[0][0] + " " + (padT + plotH) + " Z";
            var latLine = smooth(latPts);

            svg.innerHTML =
              '<defs>' +
                '<linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">' +
                  '<stop offset="0%" stop-color="#FFCD41" stop-opacity="0.38"/>' +
                  '<stop offset="100%" stop-color="#FFCD41" stop-opacity="0.0"/>' +
                '</linearGradient>' +
              '</defs>' +
              '<line x1="' + padL + '" y1="' + (padT + plotH * 0.25) + '" x2="' + (w - padR) + '" y2="' + (padT + plotH * 0.25) + '" stroke="rgba(255,205,65,0.12)" stroke-dasharray="3 3"/>' +
              '<line x1="' + padL + '" y1="' + (padT + plotH * 0.6) + '" x2="' + (w - padR) + '" y2="' + (padT + plotH * 0.6) + '" stroke="rgba(255,205,65,0.12)" stroke-dasharray="3 3"/>' +
              '<path d="' + revArea + '" fill="url(#revFill)" />' +
              '<path d="' + revLine + '" fill="none" stroke="#FFCD41" stroke-width="2.6" />' +
              '<path d="' + latLine + '" fill="none" stroke="#D71E28" stroke-width="2.3" stroke-dasharray="5 3" />';
          }

          function renderRegions() {
            var grid = document.getElementById("region-cards-grid");
            if (!grid) return;
            grid.innerHTML = REGIONS.map(function(r) {
              return '<div class="region-card" onclick="rebalanceRegion(\\'' + r.id + '\\')">' +
                '<div style="display:flex;justify-content:space-between;font-size:12px;font-weight:700;">' +
                  '<span>' + r.name + '</span>' +
                  '<span style="font-family:var(--font-mono);color:' + r.color + ';">' + r.rtt + 'ms</span>' +
                '</div>' +
                '<div style="display:flex;justify-content:space-between;font-size:11px;color:var(--color-text-secondary);margin-top:4px;">' +
                  '<span>' + r.share + '</span>' +
                  '<span style="color:' + r.color + ';">' + r.status + '</span>' +
                '</div>' +
              '</div>';
            }).join("");
          }

          function renderTier0Table(loadMult, stress) {
            var tbody = document.getElementById("tier0-tbody");
            if (!tbody) return;
            var rows = [
              {
                name: "DXC Hogan Systems (High Dollar-Value App)",
                env: "Mainframe Z-Series / CICS / Core Deposit",
                scale: "$" + Math.round(291 * loadMult) + "M/hr ($4.85M/m)",
                tps: Math.round(42800 * loadMult).toLocaleString() + " CICS TPS",
                lat: (6.8 * stress).toFixed(1) + " ms",
                status: "99.996% SLA · Optimal",
                prompt: "Show me how high Doller value application DXC Hogan Systems is running"
              },
              {
                name: "Wells Fargo Vantage",
                env: "Cloud / Microservices / Mobile",
                scale: "$" + Math.round(142 * loadMult) + "M/hr Commercial",
                tps: Math.round(19600 * loadMult).toLocaleString() + " API req/s",
                lat: (28.4 * stress).toFixed(1) + " ms",
                status: "99.985% SLA · Cloud Healthy",
                prompt: "Show Wells Fargo Vantage application monitoring details"
              },
              {
                name: "Branch Network Platform: StoreVision (SVP)",
                env: "Enterprise Branch Workstations",
                scale: "4,720 Branches · 38,450 PCs",
                tps: "98.8% Workstations Online",
                lat: (42.0 * stress).toFixed(1) + " ms",
                status: "SCEP Cert Advisory (Ring 1)",
                prompt: "Show Branch Network Platform: StoreVision (SVP) health status"
              }
            ];
            tbody.innerHTML = rows.map(function(r) {
              return '<tr class="alert-row" onclick="sendFollowUp(\\'' + r.prompt + '\\')">' +
                '<td><strong>' + r.name + '</strong></td>' +
                '<td><span class="env-badge">' + r.env + '</span></td>' +
                '<td style="font-family:var(--font-mono);color:#FFCD41;font-weight:700;">' + r.scale + '</td>' +
                '<td style="font-family:var(--font-mono);">' + r.tps + '</td>' +
                '<td style="font-family:var(--font-mono);color:#34d399;">' + r.lat + '</td>' +
                '<td><span class="sev-badge ' + (r.status.indexOf('Advisory') !== -1 ? 'sev-P2' : 'sev-OK') + '">' + r.status + '</span></td>' +
              '</tr>';
            }).join("");
          }

          window.sendFollowUp = function(text) {
            if (window.Websandbox && window.Websandbox.connection && window.Websandbox.connection.remote) {
              window.Websandbox.connection.remote.sendPrompt({ text: text });
            }
          };
        `,
        jsExpressions: [
          `updateHighDollarSim();`,
          `setInterval(function() {
            tickPhase += 0.4;
            var app = APPS[selectedAppKey] || APPS.HOGAN;
            var loadPct = parseInt(document.getElementById("rng-load")?.value || "100", 10);
            var capPct = parseInt(document.getElementById("rng-pods")?.value || "100", 10);
            var stressRatio = (loadPct / 100) / (capPct / 100);
            renderRevenueChart(app, loadPct / 100, stressRatio * (failoverActive ? 1.0 : 1.48));
          }, 950);`
        ],
      },
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SCENARIO 3: Wells Fargo Vantage Application Monitoring
  //             Primary Environment: Cloud / Microservices / Mobile
  // ═══════════════════════════════════════════════════════════════════════════
  function buildVantageScenario() {
    return {
      id: "wells-fargo-vantage",
      title: "Wells Fargo Vantage Application Monitoring (Cloud / Microservices / Mobile)",
      plan: {
        approach: "Stream real-time observability for Wells Fargo Vantage across its Cloud Kubernetes microservices, Apigee API gateways, and iOS/Android Commercial Mobile channels.",
        technology: "OpenGenUI Cloud-Native & Mobile Telemetry Engine",
        key_elements: [
          "Primary Environment: Cloud / Microservices / Mobile",
          "Kubernetes Pod Auto-Scaler, API Gateway p99 Latency & Mobile Crash-Free Rate",
          "Commercial Treasury Services Matrix (Wires, ACH, FX, Positive Pay, Mobile Biometric Auth)",
        ],
      },
      introMarkdown:
        "Here is the **Wells Fargo Vantage Application Monitoring** dashboard (`Primary Environment: Cloud / Microservices / Mobile`). Inspect real-time Kubernetes microservice health, mobile biometric authentication telemetry, and commercial treasury API performance.",
      outroMarkdown:
        "**Vantage Cloud & Mobile Summary:** All **148 Kubernetes microservice pods** across East/West cloud regions are healthy (`28.4ms` p99 API latency, `99.94%` mobile crash-free sessions). Scaling the **Mobile OAuth / Conditional Access Worker Pool** resolves the transient EMEA token retry spike.",
      activity: {
        initialHeight: 710,
        placeholderMessages: [
          "Connecting to Wells Fargo Vantage Cloud Kubernetes clusters",
          "Streaming Apigee API Gateway & Microservice mesh metrics",
          "Aggregating iOS & Android Mobile telemetry",
          "Wiring Cloud / Microservices / Mobile controls",
        ],
        css: SHARED_WIDGET_CSS,
        htmlChunks: [
          `<div class="sre-widget">
            <div class="sre-top-bar">
              <div class="sre-title-group">
                <span class="sre-eyebrow"><span class="sre-live-dot"></span> WELLS FARGO VANTAGE · APPLICATION MONITORING</span>
                <div class="sre-title">Wells Fargo Vantage — Cloud, Microservices &amp; Mobile Telemetry</div>
                <div style="margin-top:4px;">
                  <span class="env-badge">☁️ Primary Environment: Cloud / Microservices / Mobile</span>
                </div>
              </div>
              <div class="sre-controls-row">
                <button type="button" class="sre-pill-btn active" onclick="scaleVantagePods()">⚡ Auto-Scale K8s Pods (+24)</button>
                <button type="button" class="sre-pill-btn" onclick="flushMobileCdn()">📱 Purge Mobile Edge Cache</button>
              </div>
            </div>

            <div class="kpi-grid">
              <div class="kpi-card success">
                <div class="kpi-label">Cloud Microservices</div>
                <div class="kpi-value" id="van-pods">148 / 148</div>
                <div class="kpi-delta" id="van-pods-sub">Active K8s Pods · Multi-Region</div>
              </div>
              <div class="kpi-card">
                <div class="kpi-label">API Gateway p99</div>
                <div class="kpi-value" id="van-lat" style="color:#FFCD41;">28.4 ms</div>
                <div class="kpi-delta">19,600 req/sec · Apigee Mesh</div>
              </div>
              <div class="kpi-card success">
                <div class="kpi-label">Mobile App Health</div>
                <div class="kpi-value" id="van-mob">99.94%</div>
                <div class="kpi-delta">iOS &amp; Android Crash-Free Sessions</div>
              </div>
              <div class="kpi-card warning">
                <div class="kpi-label">Treasury Wire Flow</div>
                <div class="kpi-value" id="van-wire">$142M/hr</div>
                <div class="kpi-delta">Connected to DXC Hogan Settlement</div>
              </div>
            </div>

            <div class="charts-row">
              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Cloud Microservices RPS vs. Mobile Biometric Login Latency</span>
                  <div class="chart-legend">
                    <span><i class="legend-dot" style="background:#FFCD41;"></i>Cloud API RPS</span>
                    <span><i class="legend-dot" style="background:#34d399;"></i>Mobile Auth Speed</span>
                  </div>
                </div>
                <svg id="vantage-svg" viewBox="0 0 560 175" style="width:100%;height:170px;display:block;"></svg>
              </div>

              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Environment Tier Breakdown</span>
                </div>
                <div id="vantage-tiers" style="display:flex;flex-direction:column;gap:10px;margin-top:6px;"></div>
              </div>
            </div>

            <div class="alert-table-wrap">
              <table class="sre-table">
                <thead>
                  <tr>
                    <th>Vantage Microservice / Mobile Tier</th>
                    <th>Environment Layer</th>
                    <th>Active Replicas</th>
                    <th>p99 Latency</th>
                    <th>Success Rate</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody id="vantage-tbody"></tbody>
              </table>
            </div>

            <div class="followup-strip">
              <span style="font-size:11.5px;color:var(--color-text-secondary);">Pivot to related Wells Fargo platforms:</span>
              <div class="sre-controls-row">
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show me how high Doller value application DXC Hogan Systems is running')">🏛️ DXC Hogan Systems ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Branch Network Platform: StoreVision (SVP) health status')">🏦 StoreVision (SVP) Branch Health ↗</button>
              </div>
            </div>
          </div>`
        ],
        jsFunctions: `
          var podCount = 148;
          var apiLat = 28.4;
          var vPhase = 0;

          window.scaleVantagePods = function() {
            podCount += 24;
            apiLat = Math.max(16.2, apiLat - 4.8);
            document.getElementById("van-pods").textContent = podCount + " / " + podCount;
            document.getElementById("van-pods-sub").textContent = "Auto-scaled +24 K8s Pods ✓";
            document.getElementById("van-lat").textContent = apiLat.toFixed(1) + " ms";
            renderVantageAll();
          };

          window.flushMobileCdn = function() {
            document.getElementById("van-mob").textContent = "99.99%";
            renderVantageAll();
          };

          function renderVantageAll() {
            var svg = document.getElementById("vantage-svg");
            if (svg) {
              var pts1 = [42, 48, 54, 62, 70, 74, 71, 76, 82, 85].map(function(v, i) {
                var x = 24 + (i / 9) * 510;
                var y = 150 - ((v + Math.sin(vPhase + i) * 3) / 100) * 125;
                return x.toFixed(1) + "," + y.toFixed(1);
              }).join(" ");
              var pts2 = [30, 34, 38, 40, 44, 42, 38, 35, 33, 31].map(function(v, i) {
                var x = 24 + (i / 9) * 510;
                var y = 150 - ((v + Math.cos(vPhase + i) * 2.5) / 100) * 125;
                return x.toFixed(1) + "," + y.toFixed(1);
              }).join(" ");
              svg.innerHTML =
                '<polyline fill="none" stroke="#FFCD41" stroke-width="2.6" points="' + pts1 + '" />' +
                '<polyline fill="none" stroke="#34d399" stroke-width="2.4" points="' + pts2 + '" />';
            }

            var tiers = document.getElementById("vantage-tiers");
            if (tiers) {
              var tData = [
                { name: "Cloud Kubernetes Mesh (EKS/Tanzu)", val: "99.99% Uptime", pct: 98, c: "#34d399" },
                { name: "Microservices API Gateway (Apigee)", val: apiLat.toFixed(1) + "ms p99", pct: 91, c: "#FFCD41" },
                { name: "Mobile Commercial App (iOS / Android)", val: "99.94% Crash-Free", pct: 95, c: "#38bdf8" },
                { name: "DXC Hogan Real-Time Wire Bridge", val: "6.8ms Sync", pct: 97, c: "#D71E28" }
              ];
              tiers.innerHTML = tData.map(function(t) {
                return '<div>' +
                  '<div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px;">' +
                    '<span>' + t.name + '</span><span style="font-family:var(--font-mono);color:#FFCD41;">' + t.val + '</span>' +
                  '</div>' +
                  '<div style="height:7px;background:rgba(255,205,65,0.12);border-radius:999px;overflow:hidden;">' +
                    '<div style="width:' + t.pct + '%;height:100%;background:' + t.c + ';border-radius:999px;"></div>' +
                  '</div>' +
                '</div>';
              }).join("");
            }

            var tbody = document.getElementById("vantage-tbody");
            if (tbody) {
              var services = [
                { svc: "vantage-wire-initiation-svc", env: "Cloud / Microservices", rep: Math.round(podCount * 0.3) + " pods", lat: (apiLat * 0.9).toFixed(1) + " ms", sr: "99.99%", st: "Healthy" },
                { svc: "vantage-mobile-biometric-auth", env: "Mobile (iOS / Android Edge)", rep: Math.round(podCount * 0.25) + " pods", lat: (apiLat * 1.1).toFixed(1) + " ms", sr: "99.95%", st: "Healthy" },
                { svc: "vantage-treasury-fx-pricing", env: "Cloud / Microservices", rep: Math.round(podCount * 0.25) + " pods", lat: (apiLat * 0.8).toFixed(1) + " ms", sr: "99.99%", st: "Healthy" },
                { svc: "vantage-positive-pay-stream", env: "Cloud / Mobile Push", rep: Math.round(podCount * 0.2) + " pods", lat: apiLat.toFixed(1) + " ms", sr: "99.98%", st: "Healthy" }
              ];
              tbody.innerHTML = services.map(function(s) {
                return '<tr class="alert-row">' +
                  '<td><strong style="font-family:var(--font-mono);">' + s.svc + '</strong></td>' +
                  '<td><span class="env-badge">' + s.env + '</span></td>' +
                  '<td style="font-family:var(--font-mono);">' + s.rep + '</td>' +
                  '<td style="font-family:var(--font-mono);color:#FFCD41;">' + s.lat + '</td>' +
                  '<td>' + s.sr + '</td>' +
                  '<td><span class="sev-badge sev-OK">' + s.st + '</span></td>' +
                '</tr>';
              }).join("");
            }
            if (window.__reportOguiHeight) window.__reportOguiHeight();
          }

          window.sendFollowUp = function(text) {
            if (window.Websandbox && window.Websandbox.connection && window.Websandbox.connection.remote) {
              window.Websandbox.connection.remote.sendPrompt({ text: text });
            }
          };
        `,
        jsExpressions: [
          `renderVantageAll();`,
          `setInterval(function() { vPhase += 0.35; renderVantageAll(); }, 1000);`
        ],
      },
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SCENARIO 4: Branch Network Platform: StoreVision (SVP) Health Status
  //             Primary Environment: Enterprise Branch Workstations
  // ═══════════════════════════════════════════════════════════════════════════
  function buildStoreVisionScenario() {
    return {
      id: "storevision-svp-health",
      title: "Branch Network Platform: StoreVision (SVP) Health Status",
      plan: {
        approach: "Render an interactive fleet health console for Branch Network Platform: StoreVision (SVP) across 4,720 retail branches and 38,450 Enterprise Branch Workstations.",
        technology: "OpenGenUI Enterprise Branch Workstation & Peripheral Telemetry Matrix",
        key_elements: [
          "Primary Environment: Enterprise Branch Workstations (Windows 11 / Intune Managed)",
          "Regional Branch Workstation Online Ratio & Teller Peripheral Bus Status (Check Scanners, PIN Pads, Cash Recyclers)",
          "One-Click Intune SCEP Cert Renewal & SVP Peripheral Bus Reset",
        ],
      },
      introMarkdown:
        "Here is the **Branch Network Platform: StoreVision (SVP) Health Status** dashboard (`Primary Environment: Enterprise Branch Workstations`). Monitor all **4,720 retail branches**, **38,450 teller & banker workstations**, hardware peripheral buses, and Microsoft Intune compliance.",
      outroMarkdown:
        "**StoreVision (SVP) Fleet Summary:** **98.8% of Enterprise Branch Workstations** are online and transacting with **DXC Hogan Systems**. Use the **Push Intune SCEP Cert Fix** button above to heal the 460 branch workstations in the West Coast ring experiencing 802.1X Wi-Fi renewal delays.",
      activity: {
        initialHeight: 720,
        placeholderMessages: [
          "Polling 4,720 retail branch SD-WAN hubs",
          "Aggregating 38,450 StoreVision (SVP) Enterprise Branch Workstations",
          "Checking Teller Check Scanner, PIN Pad & Cash Recycler peripheral buses",
          "Rendering StoreVision (SVP) regional fleet telemetry",
        ],
        css: SHARED_WIDGET_CSS,
        htmlChunks: [
          `<div class="sre-widget">
            <div class="sre-top-bar">
              <div class="sre-title-group">
                <span class="sre-eyebrow"><span class="sre-live-dot"></span> BRANCH NETWORK PLATFORM · STOREVISION (SVP)</span>
                <div class="sre-title">Branch Network Platform: StoreVision (SVP) — Fleet Health</div>
                <div style="margin-top:4px;">
                  <span class="env-badge">🖥️ Primary Environment: Enterprise Branch Workstations</span>
                </div>
              </div>
              <div class="sre-controls-row">
                <button type="button" class="sre-pill-btn active" onclick="healSvpFleet()">🔐 Push Intune SCEP Cert Fix to Fleet</button>
                <button type="button" class="sre-pill-btn" onclick="resetPeripheralBus()">🖨️ Reset Branch Peripheral Bus</button>
              </div>
            </div>

            <div class="kpi-grid">
              <div class="kpi-card success">
                <div class="kpi-label">Branch Workstations</div>
                <div class="kpi-value" id="svp-wks">37,988 / 38,450</div>
                <div class="kpi-delta" id="svp-wks-pct">98.8% Online Across 4,720 Branches</div>
              </div>
              <div class="kpi-card warning">
                <div class="kpi-label">Intune SCEP Compliance</div>
                <div class="kpi-value" id="svp-cert" style="color:#FFCD41;">94.2%</div>
                <div class="kpi-delta" id="svp-cert-sub">462 branch PCs pending cert renewal</div>
              </div>
              <div class="kpi-card success">
                <div class="kpi-label">Peripheral Bus Health</div>
                <div class="kpi-value" id="svp-periph">99.4%</div>
                <div class="kpi-delta">Scanners · PIN Pads · Cash Recyclers</div>
              </div>
              <div class="kpi-card">
                <div class="kpi-label">Teller Session Init</div>
                <div class="kpi-value" id="svp-lat">42.0 ms</div>
                <div class="kpi-delta">DXC Hogan Host Link: OPTIMAL</div>
              </div>
            </div>

            <div class="charts-row">
              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">StoreVision (SVP) Workstation Session Load &amp; Branch SD-WAN RTT</span>
                </div>
                <svg id="svp-svg" viewBox="0 0 560 175" style="width:100%;height:170px;display:block;"></svg>
              </div>

              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Workstation Peripheral Bus Status</span>
                </div>
                <div id="svp-peripherals" style="display:flex;flex-direction:column;gap:10px;margin-top:6px;"></div>
              </div>
            </div>

            <div class="alert-table-wrap">
              <table class="sre-table">
                <thead>
                  <tr>
                    <th>Branch Territory</th>
                    <th>Environment</th>
                    <th>Active Branches</th>
                    <th>Workstations Online</th>
                    <th>Intune SCEP Status</th>
                    <th>SVP Health</th>
                  </tr>
                </thead>
                <tbody id="svp-tbody"></tbody>
              </table>
            </div>

            <div class="followup-strip">
              <span style="font-size:11.5px;color:var(--color-text-secondary);">Pivot to related Wells Fargo platforms:</span>
              <div class="sre-controls-row">
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show me how high Doller value application DXC Hogan Systems is running')">🏛️ DXC Hogan Systems ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Wells Fargo Vantage application monitoring details')">☁️ Wells Fargo Vantage ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show me top 10 alerts today part of my network and Intune infrastructure')">🚨 Top 10 Network &amp; Intune Alerts ↗</button>
              </div>
            </div>
          </div>`
        ],
        jsFunctions: `
          var svpHealed = false;
          var svpPhase = 0;

          window.healSvpFleet = function() {
            svpHealed = true;
            document.getElementById("svp-wks").textContent = "38,432 / 38,450";
            document.getElementById("svp-wks-pct").textContent = "99.95% Online · SCEP Certs Renewed ✓";
            document.getElementById("svp-cert").textContent = "99.9%";
            document.getElementById("svp-cert").style.color = "#34d399";
            document.getElementById("svp-cert-sub").textContent = "All branch workstations compliant";
            document.getElementById("svp-lat").textContent = "29.4 ms";
            renderSvpAll();
          };

          window.resetPeripheralBus = function() {
            document.getElementById("svp-periph").textContent = "99.9%";
            renderSvpAll();
          };

          function renderSvpAll() {
            var svg = document.getElementById("svp-svg");
            if (svg) {
              var pts = [48, 52, 60, 68, 75, 82, 79, 84, 88, 86].map(function(v, i) {
                var x = 24 + (i / 9) * 510;
                var y = 150 - ((v + Math.sin(svpPhase + i) * 3) / 100) * 125;
                return x.toFixed(1) + "," + y.toFixed(1);
              }).join(" ");
              svg.innerHTML =
                '<polyline fill="none" stroke="#FFCD41" stroke-width="2.8" points="' + pts + '" />';
            }

            var periph = document.getElementById("svp-peripherals");
            if (periph) {
              var pList = [
                { name: "Teller Check Scanners (USB/HID Bus)", pct: svpHealed ? 99.9 : 99.2, c: "#34d399" },
                { name: "Branch PIN Pads & Contactless NFC", pct: 99.8, c: "#FFCD41" },
                { name: "Automated Cash Recyclers (TCR)", pct: 99.5, c: "#38bdf8" },
                { name: "Intune 802.1X Workstation Wi-Fi / LAN", pct: svpHealed ? 99.9 : 94.2, c: svpHealed ? "#34d399" : "#D71E28" }
              ];
              periph.innerHTML = pList.map(function(p) {
                return '<div>' +
                  '<div style="display:flex;justify-content:space-between;font-size:11.5px;margin-bottom:3px;">' +
                    '<span>' + p.name + '</span><span style="font-family:var(--font-mono);color:#FFCD41;">' + p.pct + '%</span>' +
                  '</div>' +
                  '<div style="height:7px;background:rgba(255,205,65,0.12);border-radius:999px;overflow:hidden;">' +
                    '<div style="width:' + p.pct + '%;height:100%;background:' + p.c + ';border-radius:999px;"></div>' +
                  '</div>' +
                '</div>';
              }).join("");
            }

            var tbody = document.getElementById("svp-tbody");
            if (tbody) {
              var regions = [
                { reg: "West Coast Branch Network", br: "1,180", wks: svpHealed ? "9,810 / 9,820" : "9,360 / 9,820", cert: svpHealed ? "99.9% Verified" : "91.4% (SCEP Retry)", st: svpHealed ? "Optimal" : "Advisory" },
                { reg: "Midwest & Central Territory", br: "1,040", wks: "8,412 / 8,420", cert: "99.8% Verified", st: "Optimal" },
                { reg: "Southeast & Charlotte Hub", br: "1,310", wks: "10,640 / 10,650", cert: "99.9% Verified", st: "Optimal" },
                { reg: "Northeast & Mid-Atlantic", br: "1,190", wks: "9,554 / 9,560", cert: "99.7% Verified", st: "Optimal" }
              ];
              tbody.innerHTML = regions.map(function(r) {
                return '<tr class="alert-row">' +
                  '<td><strong>' + r.reg + '</strong></td>' +
                  '<td><span class="env-badge">Enterprise Branch Workstations</span></td>' +
                  '<td style="font-family:var(--font-mono);">' + r.br + '</td>' +
                  '<td style="font-family:var(--font-mono);">' + r.wks + '</td>' +
                  '<td style="font-family:var(--font-mono);color:#FFCD41;">' + r.cert + '</td>' +
                  '<td><span class="sev-badge ' + (r.st === 'Optimal' ? 'sev-OK' : 'sev-P2') + '">' + r.st + '</span></td>' +
                '</tr>';
              }).join("");
            }
            if (window.__reportOguiHeight) window.__reportOguiHeight();
          }

          window.sendFollowUp = function(text) {
            if (window.Websandbox && window.Websandbox.connection && window.Websandbox.connection.remote) {
              window.Websandbox.connection.remote.sendPrompt({ text: text });
            }
          };
        `,
        jsExpressions: [
          `renderSvpAll();`,
          `setInterval(function() { svpPhase += 0.35; renderSvpAll(); }, 1000);`
        ],
      },
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SCENARIO 5: Live Incident Blast-Radius & Dependency Topology
  // ═══════════════════════════════════════════════════════════════════════════
  function buildBlastRadiusScenario() {
    return {
      id: "blast-radius-topology",
      title: "Live Incident Blast-Radius & Service Dependency Topology",
      plan: {
        approach: "Map real-time upstream infrastructure faults (BGP router flap & Intune SCEP/Conditional Access latency) to downstream Wells Fargo flagship platforms: DXC Hogan Systems, Wells Fargo Vantage, and Branch Network Platform: StoreVision (SVP).",
        technology: "OpenGenUI Interactive SVG Force-Layered Topology + Live Fault Isolation Simulator",
        key_elements: [
          "Interactive Multi-Tier Dependency Graph with Flowing Telemetry Pulses",
          "Node Blast-Radius Inspector (DXC Hogan Systems, Wells Fargo Vantage, StoreVision SVP)",
          "One-Click Automated BGP Reroute & Intune SCEP Bypass Simulation",
        ],
      },
      introMarkdown:
        "Here is the **interactive Incident Blast-Radius & Dependency Topology** correlating your **Network & Intune alerts** with **DXC Hogan Systems**, **Wells Fargo Vantage** (`Cloud / Microservices / Mobile`), and **Branch Network Platform: StoreVision (SVP)** (`Enterprise Branch Workstations`).",
      outroMarkdown:
        "**Topology Insight:** Isolating `us-east-core-rtr02` onto the secondary spine and enabling cached SCEP token validation in **Microsoft Intune** eliminates packet drop across **DXC Hogan Systems**, restores **Wells Fargo Vantage** mobile token speed, and heals all **StoreVision (SVP)** branch workstations.",
      activity: {
        initialHeight: 625,
        placeholderMessages: [
          "Tracing BGP ASN 65104 & ExpressRoute adjacency paths",
          "Mapping Intune SCEP & ZeroTrust CA dependencies",
          "Computing downstream impact on DXC Hogan, Vantage & StoreVision (SVP)",
          "Rendering interactive fluidic topology graph",
        ],
        css: SHARED_WIDGET_CSS,
        htmlChunks: [
          `<div class="sre-widget">
            <div class="sre-top-bar">
              <div class="sre-title-group">
                <span class="sre-eyebrow"><span class="sre-live-dot"></span> LIVE BLAST-RADIUS TOPOLOGY · ROOT CAUSE CORRELATION</span>
                <div class="sre-title">Infrastructure-to-Platform Blast Radius &amp; Dependency Mesh</div>
                <div class="sre-subtitle">Click any node in the graph to inspect upstream root cause and downstream platform impact</div>
              </div>
              <div class="sre-controls-row">
                <button type="button" class="sre-pill-btn" id="btn-heal-topo" onclick="toggleTopologyHeal()" style="border-color:#10b981;color:#34d399;">🛠️ Isolate &amp; Heal Faulty Paths</button>
              </div>
            </div>

            <div style="background:rgba(16,11,13,0.75);border:1px solid var(--color-border-tertiary);border-radius:12px;padding:12px;margin-bottom:14px;">
              <svg id="topology-svg" viewBox="0 0 760 280" style="width:100%;height:270px;display:block;"></svg>
            </div>

            <div id="topo-node-inspector" class="inspector-drawer"></div>

            <div class="followup-strip">
              <span style="font-size:11.5px;color:var(--color-text-secondary);">Continue exploring in chat:</span>
              <div class="sre-controls-row">
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show me how high Doller value application DXC Hogan Systems is running')">🏛️ DXC Hogan Systems ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Wells Fargo Vantage application monitoring details')">☁️ Wells Fargo Vantage ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Branch Network Platform: StoreVision (SVP) health status')">🏦 StoreVision (SVP) ↗</button>
              </div>
            </div>
          </div>`
        ],
        jsFunctions: `
          var TOPO_NODES = [
            { id: "bgp", x: 110, y: 75, label: "us-east-core-rtr02", sub: "Core BGP · NET-9041", status: "critical", impact: "14.2% packet drop on East transit", detail: "Primary transit router experiencing ASN 65104 peer oscillation. Propagating latency to ExpressRoute ER-CHARLOTTE-01." },
            { id: "scep", x: 110, y: 205, label: "Intune SCEP & CA", sub: "MDM PKI · INT-8820", status: "critical", impact: "4,820 SVP & Mobile endpoints", detail: "NDES SCEP connector thread exhaustion causing 802.1X Wi-Fi re-auth delays on StoreVision (SVP) branch workstations." },
            { id: "er", x: 375, y: 75, label: "ExpressRoute & Sysplex", sub: "ER-CHARLOTTE-01", status: "warning", impact: "QoS AF21 queue at 98%", detail: "Hybrid interconnect linking Cloud microservices with DXC Hogan Systems mainframe CICS channels." },
            { id: "zt", x: 375, y: 205, label: "ZeroTrust & SD-WAN Hub", sub: "CA-ZeroTrust-Prod", status: "warning", impact: "4.6s token evaluation lag", detail: "Evaluates Intune device compliance claims for Wells Fargo Vantage mobile & StoreVision (SVP) branch workstations." },
            { id: "hogan", x: 640, y: 55, label: "DXC Hogan Systems", sub: "$291M/hr · Mainframe", status: "healthy", impact: "6.8ms CICS · 99.996% SLA", detail: "High Dollar-Value Core Banking System of Record; GDPS active-active sysplex automatically isolated East BGP jitter." },
            { id: "vantage", x: 640, y: 140, label: "Wells Fargo Vantage", sub: "Cloud / Microservices / Mobile", status: "warning", impact: "p99 28.4ms · Auto-scaled", detail: "Commercial & Corporate Treasury platform running across Cloud Kubernetes microservices and Mobile apps." },
            { id: "svp", x: 640, y: 225, label: "StoreVision (SVP)", sub: "Enterprise Branch Workstations", status: "warning", impact: "98.8% Online (4,720 Branches)", detail: "Enterprise Branch Workstations platform powering teller & platform banker desktops and branch peripherals." }
          ];

          var TOPO_EDGES = [
            ["bgp", "er"],
            ["scep", "zt"],
            ["scep", "er"],
            ["er", "hogan"],
            ["er", "vantage"],
            ["zt", "vantage"],
            ["zt", "svp"]
          ];

          var selectedNodeId = "hogan";
          var topoHealed = false;

          window.selectTopoNode = function(id) {
            selectedNodeId = id;
            renderTopology();
          };

          window.toggleTopologyHeal = function() {
            topoHealed = !topoHealed;
            var btn = document.getElementById("btn-heal-topo");
            if (btn) {
              btn.textContent = topoHealed ? "✅ Faulty Paths Isolated & Rerouted (Click to Reset)" : "🛠️ Isolate & Heal Faulty Paths";
            }
            renderTopology();
          };

          function renderTopology() {
            var svg = document.getElementById("topology-svg");
            if (!svg) return;
            var nodeMap = {};
            TOPO_NODES.forEach(function(n) { nodeMap[n.id] = n; });

            var edgesHtml = TOPO_EDGES.map(function(pair) {
              var a = nodeMap[pair[0]], b = nodeMap[pair[1]];
              var isCrit = !topoHealed && (a.status === "critical" || b.status === "warning");
              var stroke = topoHealed ? "#10b981" : (isCrit ? "#D71E28" : "#FFCD41");
              return '<line x1="' + a.x + '" y1="' + a.y + '" x2="' + b.x + '" y2="' + b.y + '" stroke="' + stroke + '" stroke-width="2.2" stroke-dasharray="6 4">' +
                '<animate attributeName="stroke-dashoffset" from="20" to="0" dur="1.2s" repeatCount="indefinite" />' +
              '</line>';
            }).join("");

            var nodesHtml = TOPO_NODES.map(function(n) {
              var st = topoHealed ? "healthy" : n.status;
              var stroke = st === "critical" ? "#D71E28" : st === "warning" ? "#FFCD41" : "#10b981";
              var fill = st === "critical" ? "rgba(215,30,40,0.22)" : st === "warning" ? "rgba(255,205,65,0.15)" : "rgba(16,185,129,0.16)";
              var isSel = n.id === selectedNodeId;
              return '<g class="node" onclick="selectTopoNode(\\'' + n.id + '\\')">' +
                '<rect x="' + (n.x - 98) + '" y="' + (n.y - 28) + '" width="196" height="56" rx="10" fill="' + fill + '" stroke="' + stroke + '" stroke-width="' + (isSel ? 2.8 : 1.5) + '" />' +
                '<text x="' + n.x + '" y="' + (n.y - 5) + '" text-anchor="middle" fill="#FAF8F5" font-size="12" font-weight="700">' + n.label + '</text>' +
                '<text x="' + n.x + '" y="' + (n.y + 13) + '" text-anchor="middle" fill="#FFCD41" font-size="10" font-family="monospace">' + (topoHealed ? "HEALED · OPTIMAL" : n.sub) + '</text>' +
              '</g>';
            }).join("");

            svg.innerHTML = edgesHtml + nodesHtml;

            var insp = document.getElementById("topo-node-inspector");
            var sel = nodeMap[selectedNodeId] || TOPO_NODES[0];
            if (insp && sel) {
              insp.innerHTML =
                '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">' +
                  '<div><strong>Selected Node: ' + sel.label + '</strong> <span class="env-badge">' + (topoHealed ? "Rerouted & Healthy" : sel.impact) + '</span></div>' +
                  '<button type="button" onclick="sendFollowUp(\\'Run automated remediation playbook for ' + sel.label + '\\')">⚡ Execute Playbook in Chat ↗</button>' +
                '</div>' +
                '<div style="font-size:12.5px;color:var(--color-text-secondary);">' + sel.detail + '</div>';
            }
            if (window.__reportOguiHeight) window.__reportOguiHeight();
          }

          window.sendFollowUp = function(text) {
            if (window.Websandbox && window.Websandbox.connection && window.Websandbox.connection.remote) {
              window.Websandbox.connection.remote.sendPrompt({ text: text });
            }
          };
        `,
        jsExpressions: [`renderTopology();`],
      },
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SCENARIO 6: Dynamic Deep-Dive / Custom SRE Query Synthesis
  // ═══════════════════════════════════════════════════════════════════════════
  function buildCustomDeepDiveScenario(userPrompt) {
    const safeSubject = (userPrompt || "Enterprise Infrastructure Telemetry")
      .replace(/[<>&"']/g, "")
      .slice(0, 78);

    return {
      id: "custom-sre-deep-dive",
      title: `UpTimeEngineUI Diagnostic: ${safeSubject}`,
      plan: {
        approach: `Synthesize live diagnostic metrics, saturation curves, and an interactive automated runbook tailored to "${safeSubject}".`,
        technology: "OpenGenUI Dynamic SRE Diagnostic Engine + Interactive Runbook Executor",
        key_elements: [
          "Live Multi-Dimensional Telemetry Curve (DXC Hogan, Vantage & StoreVision SVP)",
          "Interactive Step-by-Step Automated Remediation Runbook",
          "One-Click Verification & Rollback Controls",
        ],
      },
      introMarkdown: `I have generated an **interactive UpTimeEngineUI diagnostic & remediation workspace** for **"${safeSubject}"**. Use the interactive runbook steps below to execute live simulated checks, drain affected nodes, and verify telemetry recovery.`,
      outroMarkdown:
        "**Next Steps:** Execute each remediation step directly inside the widget above or use the quick links to pivot to **DXC Hogan Systems**, **Wells Fargo Vantage**, or **Branch Network Platform: StoreVision (SVP)**.",
      activity: {
        initialHeight: 540,
        placeholderMessages: [
          "Querying UpTimeEngineUI time-series metrics",
          "Synthesizing fluidic diagnostic curves",
          "Building interactive runbook controls",
        ],
        css: SHARED_WIDGET_CSS,
        htmlChunks: [
          `<div class="sre-widget">
            <div class="sre-top-bar">
              <div class="sre-title-group">
                <span class="sre-eyebrow"><span class="sre-live-dot"></span> UPTIMEENGINEUI DIAGNOSTIC &amp; RUNBOOK EXECUTOR</span>
                <div class="sre-title">${safeSubject}</div>
                <div class="sre-subtitle">Interactive remediation &amp; live telemetry verification</div>
              </div>
              <div class="sre-controls-row">
                <button type="button" class="sre-pill-btn active" onclick="runAllSteps()">▶ Execute Full Automated Runbook</button>
              </div>
            </div>

            <div class="kpi-grid">
              <div class="kpi-card warning">
                <div class="kpi-label">Anomaly Score</div>
                <div class="kpi-value" id="dd-score">0.84 → <span style="color:#34d399;">Live</span></div>
                <div class="kpi-delta">Correlated across 14 telemetry streams</div>
              </div>
              <div class="kpi-card">
                <div class="kpi-label">p95 Saturation</div>
                <div class="kpi-value" id="dd-sat">78.2%</div>
                <div class="kpi-delta">Target threshold &lt; 70%</div>
              </div>
              <div class="kpi-card success">
                <div class="kpi-label">Automated Runbook</div>
                <div class="kpi-value" id="dd-steps">0 / 4 Done</div>
                <div class="kpi-delta">Zero-downtime execution ready</div>
              </div>
              <div class="kpi-card">
                <div class="kpi-label">Estimated MTTR</div>
                <div class="kpi-value" id="dd-mttr">45 sec</div>
                <div class="kpi-delta">AI-assisted auto-mitigation</div>
              </div>
            </div>

            <div class="charts-row">
              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Live Telemetry Recovery Curve (Pre vs. Post Mitigation)</span>
                </div>
                <svg id="dd-svg" viewBox="0 0 520 150" style="width:100%;height:145px;display:block;"></svg>
              </div>
              <div class="chart-panel">
                <div class="chart-header">
                  <span class="chart-title">Interactive Remediation Steps</span>
                </div>
                <div id="dd-runbook-list" style="display:flex;flex-direction:column;gap:8px;"></div>
              </div>
            </div>

            <div class="followup-strip">
              <span style="font-size:11.5px;color:var(--color-text-secondary);">Pivot to another UpTimeEngineUI view:</span>
              <div class="sre-controls-row">
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show me how high Doller value application DXC Hogan Systems is running')">🏛️ DXC Hogan Systems ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Wells Fargo Vantage application monitoring details')">☁️ Wells Fargo Vantage ↗</button>
                <button type="button" class="followup-btn" onclick="sendFollowUp('Show Branch Network Platform: StoreVision (SVP) health status')">🏦 StoreVision (SVP) ↗</button>
              </div>
            </div>
          </div>`
        ],
        jsFunctions: `
          var STEPS = [
            { id: 1, name: "1. Drain degraded BGP / SCEP worker pool", done: false },
            { id: 2, name: "2. Flush stale Conditional Access & DNS cache", done: false },
            { id: 3, name: "3. Scale Vantage K8s pods & SVP NDES connectors (+50%)", done: false },
            { id: 4, name: "4. Verify DXC Hogan CICS SLA & close P1 incident", done: false }
          ];

          window.toggleStep = function(id) {
            var s = STEPS.find(function(x) { return x.id === id; });
            if (s) s.done = !s.done;
            renderDeepDive();
          };

          window.runAllSteps = function() {
            STEPS.forEach(function(s, idx) {
              setTimeout(function() {
                s.done = true;
                renderDeepDive();
              }, idx * 280);
            });
          };

          function renderDeepDive() {
            var doneCount = STEPS.filter(function(s) { return s.done; }).length;
            var sat = Math.max(34.2, 78.2 - doneCount * 11.2);
            var score = Math.max(0.08, 0.84 - doneCount * 0.19);
            document.getElementById("dd-steps").textContent = doneCount + " / 4 Done";
            document.getElementById("dd-sat").textContent = sat.toFixed(1) + "%";
            document.getElementById("dd-score").innerHTML = score.toFixed(2) + ' <span style="font-size:12px;color:#34d399;">(' + (doneCount === 4 ? 'Resolved' : 'Mitigating') + ')</span>';

            var list = document.getElementById("dd-runbook-list");
            if (list) {
              list.innerHTML = STEPS.map(function(s) {
                return '<button type="button" onclick="toggleStep(' + s.id + ')" style="display:flex;justify-content:space-between;align-items:center;text-align:left;border-color:' + (s.done ? '#10b981' : 'var(--color-border-secondary)') + ';">' +
                  '<span>' + s.name + '</span>' +
                  '<span class="sev-badge ' + (s.done ? 'sev-OK' : 'sev-P2') + '">' + (s.done ? '✓ Done' : 'Run') + '</span>' +
                '</button>';
              }).join("");
            }

            var svg = document.getElementById("dd-svg");
            if (svg) {
              var pts = [82, 88, 91, 86, 78 - doneCount * 8, 72 - doneCount * 11, 68 - doneCount * 13, 64 - doneCount * 14].map(function(v, i) {
                var x = 20 + (i / 7) * 480;
                var y = 130 - (Math.max(15, v) / 100) * 110;
                return x.toFixed(1) + "," + y.toFixed(1);
              }).join(" ");
              svg.innerHTML =
                '<polyline fill="none" stroke="' + (doneCount === 4 ? '#10b981' : '#FFCD41') + '" stroke-width="3" points="' + pts + '" />';
            }
            if (window.__reportOguiHeight) window.__reportOguiHeight();
          }

          window.sendFollowUp = function(text) {
            if (window.Websandbox && window.Websandbox.connection && window.Websandbox.connection.remote) {
              window.Websandbox.connection.remote.sendPrompt({ text: text });
            }
          };
        `,
        jsExpressions: [`renderDeepDive();`],
      },
    };
  }

  function resolveScenario(promptText) {
    const q = (promptText || "").toLowerCase();
    if (
      q.includes("vantage") ||
      (q.includes("microservices") && q.includes("mobile"))
    ) {
      return buildVantageScenario();
    }
    if (
      q.includes("storevision") ||
      q.includes("svp") ||
      q.includes("branch network") ||
      q.includes("branch workstation")
    ) {
      return buildStoreVisionScenario();
    }
    if (
      q.includes("hogan") ||
      q.includes("dxc") ||
      q.includes("dollar") ||
      q.includes("doller") ||
      q.includes("high value") ||
      q.includes("running")
    ) {
      return buildDXCHoganScenario();
    }
    if (
      q.includes("top 10") ||
      q.includes("intune") ||
      (q.includes("alert") && (q.includes("network") || q.includes("today") || q.includes("infra")))
    ) {
      return buildNetworkIntuneScenario();
    }
    if (
      q.includes("blast") ||
      q.includes("topology") ||
      q.includes("dependency") ||
      q.includes("mesh") ||
      q.includes("rtr02")
    ) {
      return buildBlastRadiusScenario();
    }
    return buildCustomDeepDiveScenario(promptText);
  }

  const STARTER_SUGGESTIONS = [
    {
      id: "starter-alerts",
      tag: "NETOPS + INTUNE MDM",
      title: "Top 10 Network & Intune Alerts Today",
      prompt: "Show me top 10 alerts today part of my network and Intune infrastructure",
    },
    {
      id: "starter-hogan",
      tag: "HIGH DOLLAR-VALUE CORE",
      title: "DXC Hogan Systems (High-Dollar App)",
      prompt: "Show me how high Doller value application DXC Hogan Systems is running",
    },
    {
      id: "starter-vantage",
      tag: "CLOUD / MICROSERVICES / MOBILE",
      title: "Wells Fargo Vantage Monitoring",
      prompt: "Show Wells Fargo Vantage application monitoring details",
    },
    {
      id: "starter-svp",
      tag: "ENTERPRISE BRANCH WORKSTATIONS",
      title: "Branch Network Platform: StoreVision (SVP)",
      prompt: "Show Branch Network Platform: StoreVision (SVP) health status",
    },
    {
      id: "starter-blast",
      tag: "DEPENDENCY TOPOLOGY",
      title: "Live Incident Blast-Radius & Topology",
      prompt: "Show live incident blast-radius and dependency topology",
    },
    {
      id: "starter-runbook",
      tag: "AUTO-REMEDIATION",
      title: "Execute BGP & SCEP Auto-Runbook",
      prompt: "Deep-dive root cause and execute remediation runbook for alert NET-9041 and INT-8820",
    },
  ];

  return {
    STARTER_SUGGESTIONS,
    resolveScenario,
  };
})();
