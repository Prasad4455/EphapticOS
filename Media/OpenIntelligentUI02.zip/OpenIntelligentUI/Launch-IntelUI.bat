@echo off
setlocal
call "%~dp0UpTimeEngineUI\Launch-UpTimeEngineUI.bat"
