# UpTimeEngineUI — Wells Fargo Brand Standards SRE Generative UI Demo

**UpTimeEngineUI** is a lightweight, zero-dependency Windows demo application built on the architecture and design patterns of **[OpenIntelligentUI](https://github.com/CopilotKit/OpenIntelligentUI)** and styled according to **Wells Fargo Brand Standards** (`#D71E28` Crimson, `#FFCD41` Stagecoach Gold, executive serif & fluidic telemetry surfaces).

It starts with a **minimal, blank chat-first interface** that greets **Devi** (and automatically detects the logged-in Windows user via `%USERNAME%`), then streams **interactive, real-time fluidic SRE dashboards** inside isolated sandboxes on demand.

---

## Quick Start on Windows (Zero Dependencies)

No `npm`, `pnpm`, Python, Docker, or API keys are required.

1. Double-click **[`Launch-UpTimeEngineUI.bat`](./Launch-UpTimeEngineUI.bat)** (or open [`index.html`](./index.html) directly in Microsoft Edge, Chrome, or Firefox).
2. Click any starter prompt card or type an SRE query in the chat box.

---

## Enterprise Platforms & Chat Prompts to Try

1. **High Dollar-Value Application: `DXC Hogan Systems`**
   > `"Show me how high Doller value application DXC Hogan Systems is running"`
   - Core Banking System of Record (`Mainframe Z-Series / CICS / Core Deposit & Settlement — CIS · IDS · PAS`).
   - Tracks `$291M/hr` (`$4.85M/min`) live settlement throughput, `42,800 CICS TPS`, `6.8ms` mainframe p99 response time, `99.996%` SLA, and an integrated switcher for **DXC Hogan Systems**, **Wells Fargo Vantage**, and **StoreVision (SVP)** with interactive transaction volume & capacity sliders.

2. **`Wells Fargo Vantage` Application Monitoring**
   > `"Show Wells Fargo Vantage application monitoring details"`
   - **Primary Environment**: `Cloud / Microservices / Mobile`
   - Monitors **148 active Kubernetes microservice pods**, Apigee API Gateway p99 latency (`28.4ms`), iOS & Android Commercial Mobile crash-free sessions (`99.94%`), and Commercial Treasury Wire/FX flows (`$142M/hr`), with interactive **Auto-Scale K8s Pods (+24)** and **Purge Mobile Edge Cache** actions.

3. **`Branch Network Platform: StoreVision (SVP)` Health Status**
   > `"Show Branch Network Platform: StoreVision (SVP) health status"`
   - **Primary Environment**: `Enterprise Branch Workstations`
   - Monitors **4,720 retail branches** and **38,450 Teller & Banker Windows 11 Workstations** (`98.8%` online), hardware peripheral buses (Check Scanners, PIN Pads, Automated Cash Recyclers), and Microsoft Intune SCEP certificate compliance with one-click **Push Intune SCEP Cert Fix to Fleet** and **Reset Branch Peripheral Bus** controls.

4. **Top 10 Network & Microsoft Intune Infrastructure Alerts Today**
   > `"Show me top 10 alerts today part of my network and Intune infrastructure"`
   - Correlates Core Network (BGP, ExpressRoute, Branch SD-WAN, Anycast DNS) and Microsoft Intune (SCEP, Conditional Access, Autopilot, Defender) alerts impacting **DXC Hogan Systems**, **Wells Fargo Vantage**, and **StoreVision (SVP)**.

5. **Live Incident Blast-Radius & Dependency Topology**
   > `"Show live incident blast-radius and dependency topology"`
   - Interactive SVG dependency graph mapping upstream BGP & Intune SCEP alerts to **DXC Hogan Systems**, **Wells Fargo Vantage**, and **StoreVision (SVP)** with one-click **Isolate & Heal Faulty Paths**.
