/**
 * UpTimeEngineUI — Main Application Controller & OpenIntelligentUI Streaming Runtime
 * Styled according to Wells Fargo Brand Standards (#D71E28 Crimson, #FFCD41 Gold).
 * Zero-dependency Windows execution with sandboxed iframe widgets, ResizeObserver
 * auto-height, ExportOverlay, and Websandbox.connection.remote.sendPrompt bridge.
 */

(function () {
  const {
    RESIZE_MESSAGE_TYPE,
    PROMPT_MESSAGE_TYPE,
    OPEN_LINK_MESSAGE_TYPE,
    buildFrameDocument,
    assembleStandaloneHtml,
  } = window.IntelUIDesignSystem;

  const { STARTER_SUGGESTIONS, resolveScenario } = window.IntelUIScenarios;

  let isAgentRunning = false;
  let widgetCounter = 0;
  let currentTheme = "dark";
  const widgetRegistry = new Map();

  // ─── Detect Logged-In Windows User / Operator Name ────────────────────────
  function detectWindowsOSUser() {
    if (window.__INTELUI_WINDOWS_USER__ && String(window.__INTELUI_WINDOWS_USER__).trim()) {
      return String(window.__INTELUI_WINDOWS_USER__).trim();
    }
    const params = new URLSearchParams(window.location.search);
    if (params.get("user")) {
      return params.get("user").trim();
    }
    try {
      const decodedHref = decodeURIComponent(window.location.href).replace(/\\/g, "/");
      const match = decodedHref.match(/\/Users\/([^/]+)\//i);
      if (match && match[1] && match[1].toLowerCase() !== "public" && match[1].toLowerCase() !== "default") {
        return match[1];
      }
    } catch (_) {
      // ignore URI decode errors
    }
    return "Devi";
  }

  function resolveActiveUser() {
    const saved = localStorage.getItem("uptimeengineui_active_user");
    if (saved && saved.trim()) return saved.trim();
    const params = new URLSearchParams(window.location.search);
    if (params.get("user")) return params.get("user").trim();
    if (window.__INTELUI_OS_USER__ && String(window.__INTELUI_OS_USER__).trim()) {
      return String(window.__INTELUI_OS_USER__).trim();
    }
    return "Devi";
  }

  function updateGreetingUI() {
    const activeUser = resolveActiveUser();
    const osUser = detectWindowsOSUser();

    const greetingNameEl = document.getElementById("greeting-user-name");
    const headerUserEl = document.getElementById("header-user-name");
    const headerAvatarEl = document.getElementById("header-user-avatar");
    const sessionSubEl = document.getElementById("welcome-session-sub");

    if (greetingNameEl) {
      greetingNameEl.textContent =
        osUser && osUser.toLowerCase() !== activeUser.toLowerCase()
          ? `${activeUser} (${osUser})`
          : activeUser;
    }
    if (headerUserEl) {
      headerUserEl.textContent = activeUser;
    }
    if (headerAvatarEl) {
      headerAvatarEl.textContent = activeUser.charAt(0).toUpperCase();
    }
    if (sessionSubEl) {
      sessionSubEl.textContent = `Authenticated Windows User: ${osUser} · UpTimeEngineUI SRE Fabric Ready`;
    }
  }

  // ─── Simple Markdown Formatter with Progressive Reveal ────────────────────
  function formatMarkdownBlock(mdText) {
    const escaped = mdText
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    const formatted = escaped
      .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
      .replace(/`([^`]+)`/g, "<code>$1</code>");
    return `<p data-answer-reveal="pending">${formatted}</p>`;
  }

  function revealMarkdownElement(container) {
    requestAnimationFrame(() => {
      const blocks = container.querySelectorAll('[data-answer-reveal="pending"]');
      blocks.forEach((b, i) => {
        setTimeout(() => {
          b.setAttribute("data-answer-reveal", "visible");
        }, i * 70);
      });
    });
  }

  // ─── OpenIntelligentUI Sandbox Message Listener (Resize + sendPrompt) ─────
  window.addEventListener("message", (event) => {
    const data = event.data;
    if (!data || typeof data !== "object") return;

    if (data.type === RESIZE_MESSAGE_TYPE && data.widgetId) {
      const entry = widgetRegistry.get(data.widgetId);
      if (entry && entry.frameContainer && typeof data.height === "number" && Number.isFinite(data.height)) {
        const clamped = Math.max(120, Math.min(Math.ceil(data.height), 4000));
        entry.frameContainer.style.height = `${clamped}px`;
      }
    } else if (data.type === PROMPT_MESSAGE_TYPE && data.text) {
      submitUserMessage(String(data.text));
    } else if (data.type === OPEN_LINK_MESSAGE_TYPE && data.url) {
      if (/^https?:\/\//i.test(String(data.url))) {
        window.open(String(data.url), "_blank", "noopener,noreferrer");
      }
    }
  });

  // ─── Render Starter Suggestions & Quick Chips ─────────────────────────────
  function initStarterSuggestions() {
    const grid = document.getElementById("starter-grid");
    const chipBar = document.getElementById("quick-chips-bar");

    if (grid) {
      grid.innerHTML = STARTER_SUGGESTIONS.map(
        (item) => `
        <button type="button" class="starter-card" data-prompt="${item.prompt.replace(/"/g, "&quot;")}">
          <div class="starter-card-top">
            <span>${item.tag}</span>
            <span>↗</span>
          </div>
          <div class="starter-card-title">${item.title}</div>
          <div class="starter-card-prompt">“${item.prompt}”</div>
        </button>
      `
      ).join("");

      grid.querySelectorAll(".starter-card").forEach((btn) => {
        btn.addEventListener("click", () => {
          const prompt = btn.getAttribute("data-prompt");
          if (prompt) submitUserMessage(prompt);
        });
      });
    }

    if (chipBar) {
      chipBar.innerHTML = STARTER_SUGGESTIONS.map(
        (item) => `
        <button type="button" class="quick-chip" data-prompt="${item.prompt.replace(/"/g, "&quot;")}">
          ⚡ ${item.title}
        </button>
      `
      ).join("");

      chipBar.querySelectorAll(".quick-chip").forEach((btn) => {
        btn.addEventListener("click", () => {
          const prompt = btn.getAttribute("data-prompt");
          if (prompt) submitUserMessage(prompt);
        });
      });
    }
  }

  // ─── OpenIntelligentUI Streaming Turn Execution ───────────────────────────
  async function submitUserMessage(rawText) {
    const text = (rawText || "").trim();
    if (!text || isAgentRunning) return;

    isAgentRunning = true;
    const inputEl = document.getElementById("composer-input");
    const sendBtn = document.getElementById("composer-send-btn");
    if (inputEl) inputEl.value = "";
    if (sendBtn) sendBtn.disabled = true;

    const welcomeScreen = document.getElementById("welcome-screen");
    if (welcomeScreen) welcomeScreen.classList.add("hidden");

    const threadList = document.getElementById("thread-list");
    if (!threadList) return;

    // 1. Append User Message
    const userMsgEl = document.createElement("div");
    userMsgEl.className = "msg-user";
    userMsgEl.setAttribute("data-testid", "copilot-user-message");
    userMsgEl.textContent = text;
    threadList.appendChild(userMsgEl);

    userMsgEl.scrollIntoView({ block: "start", behavior: "smooth" });

    // 2. Append Assistant Message Shell
    const assistantEl = document.createElement("div");
    assistantEl.className = "msg-assistant";
    assistantEl.setAttribute("data-testid", "copilot-assistant-message");

    const scenario = resolveScenario(text);
    const widgetId = `ogui-widget-${++widgetCounter}`;

    assistantEl.innerHTML = `
      <div class="assistant-header">
        <span>UpTimeEngineUI SRE Agent</span>
        <span class="assistant-badge">openGenerativeUI · generateSandboxedUi</span>
      </div>
      <details class="ogui-plan-card" open id="plan-${widgetId}">
        <summary>
          <span class="ogui-spinner" id="plan-icon-${widgetId}"></span>
          <span id="plan-title-${widgetId}">Planning visualization…</span>
        </summary>
        <div class="ogui-plan-body">
          <span class="ogui-tech-pill">${scenario.plan.technology}</span>
          <p>${scenario.plan.approach}</p>
          <ul class="ogui-plan-elements">
            ${scenario.plan.key_elements.map((el) => `<li>${el}</li>`).join("")}
          </ul>
        </div>
      </details>
      <div class="answer-markdown" id="intro-md-${widgetId}"></div>
      <div class="ogui-export-wrapper" id="export-wrap-${widgetId}">
        <div class="ogui-export-toolbar" id="toolbar-${widgetId}">
          <button type="button" class="ogui-toolbar-btn" id="btn-copy-${widgetId}" title="Copy standalone HTML">
            📋 Copy HTML
          </button>
          <button type="button" class="ogui-toolbar-btn" id="btn-dl-${widgetId}" title="Download standalone dashboard HTML">
            ⬇ Export .html
          </button>
        </div>
        <div class="ogui-sandbox-frame-container" id="sandbox-container-${widgetId}" style="height: ${scenario.activity.initialHeight}px;">
          <div class="ogui-loading-overlay" id="loading-${widgetId}">
            <div class="ogui-loading-ring"></div>
            <div class="ogui-loading-phrase" id="phrase-${widgetId}">${scenario.activity.placeholderMessages[0]}...</div>
          </div>
        </div>
      </div>
      <div class="answer-markdown" id="outro-md-${widgetId}"></div>
    `;

    threadList.appendChild(assistantEl);

    const phrases = scenario.activity.placeholderMessages;
    let phraseIdx = 0;
    const phraseEl = document.getElementById(`phrase-${widgetId}`);
    const phraseTimer = setInterval(() => {
      phraseIdx = (phraseIdx + 1) % phrases.length;
      if (phraseEl) phraseEl.textContent = `${phrases[phraseIdx]}...`;
    }, 360);

    await delay(420);

    const planDetails = document.getElementById(`plan-${widgetId}`);
    const planIcon = document.getElementById(`plan-icon-${widgetId}`);
    const planTitle = document.getElementById(`plan-title-${widgetId}`);
    if (planIcon) {
      planIcon.className = "ogui-plan-check";
      planIcon.textContent = "✓";
    }
    if (planTitle) {
      planTitle.textContent = `Plan: ${scenario.plan.technology}`;
    }
    if (planDetails) {
      planDetails.open = false;
    }

    const introContainer = document.getElementById(`intro-md-${widgetId}`);
    if (introContainer) {
      introContainer.innerHTML = formatMarkdownBlock(scenario.introMarkdown);
      revealMarkdownElement(introContainer);
    }

    await delay(480);

    const fullHtml = scenario.activity.htmlChunks.join("\n");
    const frameContainer = document.getElementById(`sandbox-container-${widgetId}`);
    const loadingOverlay = document.getElementById(`loading-${widgetId}`);

    if (frameContainer) {
      const iframe = document.createElement("iframe");
      iframe.style.width = "100%";
      iframe.style.height = "100%";
      iframe.style.border = "none";
      iframe.style.backgroundColor = "transparent";
      iframe.setAttribute("sandbox", "allow-scripts allow-same-origin allow-downloads");

      const frameDoc = buildFrameDocument({
        widgetId,
        css: scenario.activity.css,
        html: fullHtml,
        jsFunctions: scenario.activity.jsFunctions,
        jsExpressions: scenario.activity.jsExpressions,
        theme: currentTheme,
      });

      widgetRegistry.set(widgetId, {
        frameContainer,
        iframe,
        scenario,
        fullHtml,
      });

      iframe.srcdoc = frameDoc;
      frameContainer.appendChild(iframe);

      iframe.addEventListener("load", () => {
        clearInterval(phraseTimer);
        if (loadingOverlay) loadingOverlay.classList.add("hidden");
        frameContainer.classList.add("ready");
      });
    } else {
      clearInterval(phraseTimer);
    }

    const copyBtn = document.getElementById(`btn-copy-${widgetId}`);
    const dlBtn = document.getElementById(`btn-dl-${widgetId}`);
    const standaloneHtml = assembleStandaloneHtml({
      title: scenario.title,
      css: scenario.activity.css,
      html: fullHtml,
      jsFunctions: scenario.activity.jsFunctions,
      jsExpressions: scenario.activity.jsExpressions,
      theme: currentTheme,
    });

    if (copyBtn) {
      copyBtn.addEventListener("click", () => {
        navigator.clipboard?.writeText(standaloneHtml).then(() => {
          copyBtn.textContent = "✓ Copied!";
          setTimeout(() => {
            copyBtn.textContent = "📋 Copy HTML";
          }, 1600);
        });
      });
    }

    if (dlBtn) {
      dlBtn.addEventListener("click", () => {
        const blob = new Blob([standaloneHtml], { type: "text/html;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${scenario.id}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      });
    }

    await delay(320);

    const outroContainer = document.getElementById(`outro-md-${widgetId}`);
    if (outroContainer) {
      outroContainer.innerHTML = formatMarkdownBlock(scenario.outroMarkdown);
      revealMarkdownElement(outroContainer);
    }

    isAgentRunning = false;
    if (sendBtn) sendBtn.disabled = false;
    if (inputEl) inputEl.focus();
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function resetToNewChat() {
    if (isAgentRunning) return;
    const threadList = document.getElementById("thread-list");
    const welcomeScreen = document.getElementById("welcome-screen");
    if (threadList) threadList.innerHTML = "";
    if (welcomeScreen) welcomeScreen.classList.remove("hidden");
    widgetRegistry.clear();
  }

  function toggleTheme() {
    currentTheme = currentTheme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", currentTheme);
    const themeBtn = document.getElementById("btn-theme-toggle");
    if (themeBtn) {
      themeBtn.textContent = currentTheme === "dark" ? "☀ Light" : "🌙 Dark";
    }
    widgetRegistry.forEach((entry) => {
      try {
        const doc = entry.iframe.contentDocument;
        if (doc && doc.documentElement) {
          doc.documentElement.setAttribute("data-theme", currentTheme);
        }
      } catch (_) {
        // ignore cross-frame if any
      }
    });
  }

  function initUserModal() {
    const modal = document.getElementById("user-modal");
    const openBtn = document.getElementById("btn-open-user-modal");
    const cancelBtn = document.getElementById("btn-cancel-user-modal");
    const saveBtn = document.getElementById("btn-save-user-modal");
    const input = document.getElementById("input-operator-name");
    const presetsWrap = document.getElementById("user-presets");

    const osUser = detectWindowsOSUser();
    const presets = Array.from(new Set(["Devi", osUser, "SRE Commander"]));

    if (presetsWrap) {
      presetsWrap.innerHTML = presets
        .map(
          (name) =>
            `<button type="button" class="quick-chip" data-preset="${name}">Use “${name}”</button>`
        )
        .join("");
      presetsWrap.querySelectorAll("button").forEach((b) => {
        b.addEventListener("click", () => {
          if (input) input.value = b.getAttribute("data-preset") || "Devi";
        });
      });
    }

    if (openBtn && modal) {
      openBtn.addEventListener("click", () => {
        if (input) input.value = resolveActiveUser();
        modal.classList.remove("hidden");
      });
    }
    if (cancelBtn && modal) {
      cancelBtn.addEventListener("click", () => modal.classList.add("hidden"));
    }
    if (saveBtn && modal) {
      saveBtn.addEventListener("click", () => {
        const val = (input?.value || "").trim() || "Devi";
        localStorage.setItem("uptimeengineui_active_user", val);
        updateGreetingUI();
        modal.classList.add("hidden");
      });
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    updateGreetingUI();
    initStarterSuggestions();
    initUserModal();

    const form = document.getElementById("composer-form");
    const input = document.getElementById("composer-input");
    const newChatBtn = document.getElementById("btn-new-chat");
    const themeBtn = document.getElementById("btn-theme-toggle");

    if (form && input) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        submitUserMessage(input.value);
      });
    }

    if (newChatBtn) {
      newChatBtn.addEventListener("click", resetToNewChat);
    }

    if (themeBtn) {
      themeBtn.addEventListener("click", toggleTheme);
    }
  });
})();
